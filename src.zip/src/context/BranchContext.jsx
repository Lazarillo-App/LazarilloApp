// src/context/BranchContext.jsx
// Solo exporta BranchProvider y BranchCtx.
// El hook useBranch vive en useBranch.js para no romper Fast Refresh.
/* eslint-disable react-refresh/only-export-components */
import React, {
  createContext, useEffect, useState, useCallback, useMemo,
} from 'react';
import { BranchesAPI } from '@/servicios/apiBranches';
import { useBusiness } from './BusinessContext';

export const BranchCtx = createContext(null);

// Key de localStorage para persistir la sucursal activa por negocio
const branchKey = (bizId) => `activeBranchId_${bizId || 'default'}`;

export function BranchProvider({ children }) {
  const { activeBusinessId } = useBusiness() || {};

  const [branches, setBranches]             = useState([]);
  const [activeBranchId, setActiveBranchId] = useState(null);
  const [loading, setLoading]               = useState(false);

  // Cargar sucursales cuando cambia el negocio activo
  const loadBranches = useCallback(async (bizId) => {
    const id = bizId || activeBusinessId;
    if (!id) {
      setBranches([]);
      setActiveBranchId(null);
      return;
    }
    setLoading(true);
    try {
      // BranchesAPI.list(bizId) → GET /api/businesses/:bizId/branches
      const res  = await BranchesAPI.list(id);
      const list = res?.branches || [];
      setBranches(list);

      // Restaurar la sucursal que el usuario tenía seleccionada para este negocio
      const stored    = localStorage.getItem(branchKey(id));
      const storedNum = stored ? Number(stored) : null;
      const exists    = storedNum && list.some(b => b.id === storedNum);
      setActiveBranchId(exists ? storedNum : null);
    } catch (e) {
      console.error('[BranchContext] loadBranches:', e);
      setBranches([]);
      setActiveBranchId(null);
    } finally {
      setLoading(false);
    }
  }, [activeBusinessId]);

  // Cargar al montar y cuando cambia el negocio
  useEffect(() => {
    loadBranches(activeBusinessId);
  }, [activeBusinessId]); // eslint-disable-line react-hooks/exhaustive-deps

  // Refrescar ante eventos de mutación de sucursales
  useEffect(() => {
    const onChanged = () => loadBranches(activeBusinessId);
    window.addEventListener('branch:created', onChanged);
    window.addEventListener('branch:updated', onChanged);
    window.addEventListener('branch:deleted', onChanged);
    return () => {
      window.removeEventListener('branch:created', onChanged);
      window.removeEventListener('branch:updated', onChanged);
      window.removeEventListener('branch:deleted', onChanged);
    };
  }, [activeBusinessId, loadBranches]);

  // También refrescar cuando el negocio cambia (event bus)
  useEffect(() => {
    const onSwitched = (ev) => {
      const newBizId = ev?.detail?.bizId;
      if (newBizId) loadBranches(newBizId);
    };
    window.addEventListener('business:switched', onSwitched);
    return () => window.removeEventListener('business:switched', onSwitched);
  }, [loadBranches]);

  const setActiveBranch = useCallback((id) => {
    const newId = id === null || id === undefined ? null : Number(id);
    setActiveBranchId(newId);
    if (activeBusinessId) {
      if (newId) localStorage.setItem(branchKey(activeBusinessId), String(newId));
      else       localStorage.removeItem(branchKey(activeBusinessId));
    }
  }, [activeBusinessId]);

  const activeBranch = useMemo(
    () => branches.find(b => b.id === activeBranchId) || null,
    [branches, activeBranchId]
  );

  const hasBranches = branches.length > 0;

  const value = useMemo(() => ({
    branches,
    activeBranchId,
    activeBranch,
    hasBranches,
    loading,
    setActiveBranch,
    loadBranches,
  }), [
    branches, activeBranchId, activeBranch,
    hasBranches, loading, setActiveBranch, loadBranches,
  ]);

  return <BranchCtx.Provider value={value}>{children}</BranchCtx.Provider>;
}