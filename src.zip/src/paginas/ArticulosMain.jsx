/* eslint-disable no-empty */
/* eslint-disable no-unused-vars */
import { showAlert } from '../servicios/appAlert';
import { showPrompt } from '../servicios/appPrompt';
import { showConfirm } from '../servicios/appConfirm';
import React, { useMemo, useState, useEffect, useRef, useCallback } from 'react';
import { useOrganization } from '../context/OrganizationContext';
import TablaArticulos from '../componentes/TablaArticulos';
import SidebarCategorias from '../componentes/SidebarCategorias';
import SalesPickerIcon from '../componentes/SalesPickerIcon';
import { lastNDaysUntilYesterday, daysByMode } from '../utils/fechas';
import { useBusiness } from '../context/BusinessContext';
import { BusinessesAPI, httpBiz, RecetasAPI, PriceConfigAPI } from "../servicios/apiBusinesses";
import { BASE } from "../servicios/apiBase";
import { applyCreateGroup, applyAppend, applyRemove, applyMove } from '../utils/groupMutations';
import { obtenerAgrupaciones, actualizarAgrupacion, eliminarAgrupacion } from "../servicios/apiAgrupaciones";
import { emitGroupsChanged } from "../utils/groupsBus";
import { buildAgrupacionesIndex, findGroupsForQuery } from '../servicios/agrupacionesIndex';
import { Snackbar, Alert, Button, Box, Dialog, DialogTitle, DialogContent, DialogActions, Typography, Stack } from '@mui/material';
import { emitUiAction } from '../servicios/uiEvents';
import { clearVentasCache } from '../servicios/apiVentas';
import { downloadVentasCSV } from '../servicios/apiVentas';
import VentasActionsMenu from '../componentes/VentasActionsMenu';
import { useSalesData, getVentasFromMap } from '../hooks/useSalesData';
import { useFirstDate } from '../hooks/useFirstDate';
import UploadCSVModal from '../componentes/UploadCSVModal';
import Buscador from '@/componentes/Buscador';
import SubBusinessCreateModal from '../componentes/SubBusinessCreateModal';
import BusinessCreateModal from '../componentes/BusinessCreateModal';
import ReactDOM from 'react-dom';
import instructionImage1 from '../assets/brand/maxirest-menu.jpeg';
import instructionImage2 from '../assets/brand/maxirest-config.jpeg';
import { getOrgPriceListConfig, getBusinessPriceList } from '@/servicios/apiPriceLists';
import {
  notifyGroupRenamed,
  notifyGroupDeleted,
  notifyGroupMovedToDivision,
  notifyGroupFavoriteChanged,
  notifyGroupCreated,
} from '../servicios/notifyGroupActions';
import { saveRedondeoConfig, getRedondeoConfig } from '@/utils/redondeoUtils';
import { useConfig } from '@/context/ConfigContext';
import { useArticleSelection } from '@/hooks/useArticleSelection';
import SelectionToolbar from '@/componentes/SelectionToolbar';
import { usePersistUiActions } from '@/hooks/usePersistUiActions';
import SucursalSelector from '@/componentes/SucursalSelector';
import { useBranch } from '@/hooks/useBranch';
import '../css/global.css';
import '../css/theme-layout.css';

// ✅ CAMBIO 1: Favorita ahora es por negocio
const getFavKey = (bizId) => `favGroupId_${bizId || 'default'}`;
const VIEW_KEY = 'lazarillo:ventasViewMode';

const norm = (s) => String(s || '').trim().toLowerCase();

const getArtId = (a) => {
  const raw =
    a?.article_id ??
    a?.articulo_id ??
    a?.articuloId ??
    a?.idArticulo ??
    a?.id ??
    a?.codigo ??
    a?.code;

  const id = Number(raw);
  return Number.isFinite(id) && id > 0 ? id : null;
};

const normalize = (s) =>
  String(s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();

const esTodoGroup = (g) => {
  const n = norm(g?.nombre);
  return (
    n === 'todo' ||
    n === 'sin agrupacion' ||
    n === 'sin agrupación' ||
    n === 'sin agrupar' ||
    n === 'sin grupo'
  );
};

const isDiscontinuadosGroup = (g) => {
  const n = norm(g?.nombre);
  return n === 'discontinuados' || n === 'descontinuados';
};

const isRealTodoGroup = (g, todoId) => {
  if (!g) return false;
  if (!Number.isFinite(Number(todoId))) return false;
  return Number(g.id) === Number(todoId);
};

// Fallback por nombre para cuando todoGroupId aún no está seteado
const esTodoGroupByName = (g) => {
  if (!g) return false;
  const n = String(g.nombre || g.name || '').trim().toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  return n === 'todo' || n === 'sin agrupacion' || n === 'sin agrupar' || n === 'sin grupo';
};

export default function ArticulosMain(props) {
  const {
    syncVersion: syncVersionProp = 0,
    activeBizId: activeBizIdProp = '',
  } = props;

  const {
    activeDivisionId,
    activeDivisionAgrupacionIds,
    assignedAgrupacionIds,
    refetchAssignedAgrupaciones,
  } = useBusiness();

  const [syncVersion, setSyncVersion] = useState(0);
  const [categorias, setCategorias] = useState([]);
  const [agrupaciones, setAgrupaciones] = useState([]);
  const [agrupacionSeleccionada, setAgrupacionSeleccionada] = useState(null);
  const [categoriaSeleccionada, setCategoriaSeleccionada] = useState(null);
  const [discoOrigenById, setDiscoOrigenById] = useState({});
  const [filtroBusqueda, setFiltroBusqueda] = useState('');
  const [activeIds, setActiveIds] = useState(new Set());
  const [reloadKey, setReloadKey] = useState(0);
  const [recetasCostos, setRecetasCostos] = useState({});
  // ── Price config save con confirmación y deshacer ──
  const [dlgConfirm, setDlgConfirm] = useState(null);
  const prevConfigRef = React.useRef(null);
  const [priceConfig, setPriceConfig] = useState({ byArticle: {}, byRubro: {}, byAgrupacion: {} });
  // Leer globalCostoIdeal del contexto global — se actualiza automáticamente desde ConfiguracionMain
  const { articulosCostoIdeal: globalCostoIdeal } = useConfig();
  // Estado de sincronización — se activa con sync:start y se apaga con sync:completed
  // Al montar, verificar si hay un sync en curso (puede haberse iniciado antes de navegar aquí)
  const [isSyncing, setIsSyncing] = useState(() => {
    try {
      const bizId = localStorage.getItem('activeBusinessId');
      return bizId ? sessionStorage.getItem(`lazarillo:syncing:${bizId}`) === '1' : false;
    } catch { return false; }
  });
  const [syncMsg, setSyncMsg] = useState(() =>
    (() => { try { const b = localStorage.getItem('activeBusinessId'); return b && sessionStorage.getItem(`lazarillo:syncing:${b}`) === '1' ? 'Sincronizando con MaxiRest…' : ''; } catch { return ''; } })()
  );
  const [favoriteGroupId, setFavoriteGroupId] = useState(null);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [subBizModalOpen, setSubBizModalOpen] = useState(false);
  const [groupForSubBiz, setGroupForSubBiz] = useState(null);
  const [alertaVentas, setAlertaVentas] = useState(null);
  const [orgNameModalOpen, setOrgNameModalOpen] = useState(false);
  const [orgNameInput, setOrgNameInput] = useState('');
  const [orgNameSaving, setOrgNameSaving] = useState(false);
  const [ventasOverrides, setVentasOverrides] = useState(() => new Map());
  const [searchText, setSearchText] = useState('');
  const [allPriceLists, setAllPriceLists] = useState([]);
  const { activeBusinessId, selectBusiness, setActiveBusiness } = useBusiness();
  const activeBizId = String(activeBusinessId || '');
  const [visibleSubrubro, setVisibleSubrubro] = useState(null);
  const showMiss = useCallback((msg) => { setMissMsg(msg); setMissOpen(true); }, []);
  const {
    selectionMode, selectedIds, saving: selectionSaving,
    toggleMode, toggleSelected, selectAll, clearSelection,
    lists, loadingLists, activeListId, activeListItems,
    createList, addToExistingList, deleteList, selectList,
    linkGroups, linkByArticleId, createLink, deleteLink, removeMemberFromLink,
  } = useArticleSelection({
    bizId: activeBizId,
    notify: showMiss,
  });

  const { activeBranchId, activeBranch, activeBranchFilter, branches: allBranches, rawBranches } = useBranch() || {};

  // Inicializar rango con valores reales desde el inicio
  const RANGO_KEY = 'lazarillo:rangoVentas';

  const [rango, setRango] = useState(() => {
    try {
      const saved = localStorage.getItem(RANGO_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Validar que tenga la forma correcta
        if (parsed?.from && parsed?.to && /^\d{4}-\d{2}-\d{2}$/.test(parsed.from)) {
          return parsed;
        }
      }
    } catch { }
    const def = lastNDaysUntilYesterday(daysByMode('7'));
    return { mode: '7', from: def.from, to: def.to };
  });

  const periodo = useMemo(() => {
    if (rango.from && rango.to) {
      return { from: rango.from, to: rango.to };
    }
    return lastNDaysUntilYesterday(daysByMode(rango.mode || '7'));
  }, [rango]);

  useEffect(() => {
    clearSelection();
    toggleMode(null);
  }, [activeBizId]);

  useEffect(() => {
  }, [activeBranchFilter]);

  const periodoRef = useRef(periodo);
  const sidebarScrollRef = useRef(null);   // para preservar scroll del sidebar
  useEffect(() => {
    periodoRef.current = periodo;
  }, [periodo]);

  // Limpiar overrides al cambiar de negocio para evitar que
  // los valores del negocio anterior se sumen al nuevo
  useEffect(() => {
    setVentasOverrides(new Map());
  }, [activeBizId]);

  // Ventas por sucursal — solo cuando hay 2+ sucursales
  const [ventasMapByBranch, setVentasMapByBranch] = React.useState({});
  useEffect(() => {

    // Solo calcular cuando está en modo "Todas" — rawBranches son las sucursales reales
    const branches = rawBranches || [];
    if (branches.length === 0 || !activeBizId || !periodo.from || !periodo.to) {
      setVentasMapByBranch({});
      return;
    }
    let cancelled = false;
    const token = localStorage.getItem('token') || '';
    const MAXI_ENABLED = import.meta.env.VITE_MAXI_ENABLED === 'true';
    // Solo fetchear sucursales reales para columnas paralelas
    // La columna "Ventas $" ya muestra el total de todas
    const allToFetch = [...branches];
    Promise.all(
      allToFetch.map(async (branch) => {
        const branchParam = branch.isMain ? '' : `&branch_id=${branch.id}`;
        const url = MAXI_ENABLED
          ? `https://lazarilloapp-backend.onrender.com/api/businesses/${activeBizId}/sales/items?from=${periodo.from}&to=${periodo.to}${branchParam}`
          : `https://lazarilloapp-backend.onrender.com/api/businesses/${activeBizId}/sales/summary?from=${periodo.from}&to=${periodo.to}&source=csv${branchParam}`;
        try {
          const res = await fetch(url, { headers: { Authorization: `Bearer ${token}`, 'X-Business-Id': String(activeBizId) } });
          const data = await res.json();
          const rows = Array.isArray(data) ? data : (data?.items || []);
          const map = new Map();
          for (const r of rows) {
            const id = Number(r.article_id ?? r.articuloId ?? r.id);
            if (!Number.isFinite(id) || id <= 0) continue;
            map.set(id, { qty: Number(r.total_qty ?? r.qty ?? 0), amount: Number(r.total_amount ?? r.amount ?? 0) });
            map.set(String(id), { qty: Number(r.total_qty ?? r.qty ?? 0), amount: Number(r.total_amount ?? r.amount ?? 0) });
          }
          return { branchId: branch.id, map };
        } catch { return { branchId: branch.id, map: new Map() }; }
      })
    ).then(results => {
      if (cancelled) return;
      const byBranch = {};
      results.forEach(({ branchId, map }) => { byBranch[branchId] = map; });
      setVentasMapByBranch(byBranch);
    });
    return () => { cancelled = true; };
  }, [allBranches, activeBizId, periodo.from, periodo.to, syncVersion]);

  const { rootBusiness, allBusinesses, updateOrg, organization } = useOrganization() || {};

  usePersistUiActions(activeBizId);

  const {
    ventasMap,
    ventasPorArticulo,
    isLoading: ventasLoading,
    error: ventasError,
    refetch: refetchVentas,
  } = useSalesData({
    businessId: activeBizId,
    from: periodo.from,
    to: periodo.to,
    enabled: !!activeBizId && !!periodo.from && !!periodo.to,
    syncVersion,
    // 'main' = sin branch_id, null = todas, number = sucursal específica
    branchId: activeBranchFilter?.mode === 'main' ? 'main'
      : activeBranchFilter?.mode === 'branch' ? activeBranchFilter.branchId
        : null,   // modo 'all' → suma total de todas las sucursales
  });

  const [viewModeGlobal, setViewModeGlobal] = useState(() => {
    if (typeof window === 'undefined') return 'by-subrubro';
    const raw = localStorage.getItem(VIEW_KEY);
    return raw === 'by-categoria' ? 'by-categoria' : 'by-subrubro';
  });

  useEffect(() => {
    try { localStorage.setItem(VIEW_KEY, viewModeGlobal); } catch { }
  }, [viewModeGlobal]);

  const [viewModeByGroup, setViewModeByGroup] = useState({});

  // ✅ Cargar prefs por negocio con scope 'articulo' — limpiar antes para no mostrar prefs viejas
  useEffect(() => {
    setViewModeByGroup({}); // limpiar inmediatamente al cambiar negocio
    if (!activeBizId) return;

    (async () => {
      try {
        const resp = await BusinessesAPI.getViewPrefs(activeBizId, { scope: 'articulo' });
        const byGroup = resp?.byGroup || resp?.byArticuloGroup || {};
        setViewModeByGroup(byGroup);
      } catch (e) {
        setViewModeByGroup({});
      }
    })();
  }, [activeBizId]);

  // ✅ Al cambiar agrupación, aplicar la vista guardada para esa agrupación
  useEffect(() => {
    const gId = Number(agrupacionSeleccionada?.id);
    if (!Number.isFinite(gId) || gId <= 0) return;
    const saved = viewModeByGroup[gId] || viewModeByGroup[String(gId)];
    if (saved === 'by-subrubro' || saved === 'by-categoria') {
      setViewModeGlobal(saved);
    }
  }, [agrupacionSeleccionada?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleChangeListMode = useCallback(
    (mode) => {
      setViewModeGlobal(mode);
      try { localStorage.setItem(VIEW_KEY, mode); } catch { }

      const g = agrupacionSeleccionada;
      const bid = activeBizId;
      const groupId = Number(g?.id);

      if (bid && Number.isFinite(groupId)) {
        setViewModeByGroup((prev) => ({
          ...prev,
          [groupId]: mode,
        }));

        BusinessesAPI.saveViewPref(bid, {
          agrupacionId: groupId,
          viewMode: mode,
          scope: 'articulo', // ✅ scope explícito para no mezclar con insumos
        }).catch((e) => {
          console.error('saveViewPref error', e);
        });
      }
    },
    [agrupacionSeleccionada, activeBizId]
  );

  const getGroupItemsRaw = (g) => {
    if (!g) return [];
    // Combinar articulos JSONB (objetos) + app_articles_ids (array de IDs numericos)
    const fromJsonb = Array.isArray(g.articulos) ? g.articulos
      : Array.isArray(g.items) ? g.items
        : Array.isArray(g.data) ? g.data
          : [];
    const fromAppIds = Array.isArray(g.app_articles_ids)
      ? g.app_articles_ids.map(id => ({ id: Number(id) })).filter(a => a.id > 0)
      : [];
    if (!fromAppIds.length) return fromJsonb;
    // Combinar sin duplicar: app_articles_ids tiene precedencia (tiene IDs reales)
    const seenIds = new Set(fromAppIds.map(a => a.id));
    const extra = fromJsonb.filter(a => {
      const id = Number(a?.id ?? a?.articulo_id);
      return id > 0 && !seenIds.has(id);
    });
    return [...fromAppIds, ...extra];
  };

  const agIndex = useMemo(() => buildAgrupacionesIndex(agrupaciones || []), [agrupaciones]);

  const [missMsg, setMissMsg] = useState('');
  const [missOpen, setMissOpen] = useState(false);

  const lastManualPickRef = useRef(0);
  const markManualPick = useCallback(() => { lastManualPickRef.current = Date.now(); }, []);

  const [orgAssignedIds, setOrgAssignedIds] = React.useState(null);

  const handleRangoChange = useCallback((nuevoRango) => {
    setRango(nuevoRango);
    try { localStorage.setItem(RANGO_KEY, JSON.stringify(nuevoRango)); } catch { }
  }, []);

  // branchId efectivo para firstDate
  const effectiveBranchIdForFirst = activeBranchFilter?.mode === 'branch'
    ? activeBranchFilter.branchId
    : activeBranchFilter?.mode === 'main'
      ? 'main'
      : null; // 'all' → primera fecha global

  // Primera fecha histórica de ventas — específica por negocio
  const { firstDate: firstDateVentas, loadingFirst: loadingFirstVentas } =
    useFirstDate(activeBizId, 'sales', effectiveBranchIdForFirst);

  // Si el rango activo es "Histórico" y cambia el negocio/firstDate, actualizar el from automáticamente
  useEffect(() => {
    if (rango.mode === 'all' && firstDateVentas) {
      setRango(prev => ({ ...prev, from: firstDateVentas }));
    }
  }, [firstDateVentas]); // eslint-disable-line react-hooks/exhaustive-deps

  const refetchAgrupaciones = React.useCallback(async () => {
    // Guardar scroll del sidebar antes del refetch y restaurarlo después
    const scrollEl = sidebarScrollRef.current;
    const savedScroll = scrollEl ? scrollEl.scrollTop : 0;

    if (!activeBizId) {
      setAgrupaciones([]);
      setOrgAssignedIds(null);
      return [];
    }

    try {
      const { list, orgAssignedIds: assigned } = await obtenerAgrupaciones(activeBizId, activeDivisionId ?? null);

      // Filtrar agrupaciones movidas a otro negocio
      const filtered = (list || []).filter(ag => !ag.moved_to_business_id);

      if (Array.isArray(filtered)) setAgrupaciones(filtered);
      setOrgAssignedIds(assigned);

      // Restaurar scroll después de que React aplique los cambios al DOM
      if (scrollEl && savedScroll > 0) {
        requestAnimationFrame(() => {
          if (sidebarScrollRef.current) sidebarScrollRef.current.scrollTop = savedScroll;
        });
      }

      return filtered || [];
    } catch (e) {
      console.error('[ArticulosMain] ❌ Error cargando agrupaciones:', e);
      setAgrupaciones([]);
      setOrgAssignedIds(null);
      return [];
    }
  }, [activeBizId, activeDivisionId]);

  useEffect(() => {
    setAgrupacionSeleccionada(null);
    setCategoriaSeleccionada(null);
    setFiltroBusqueda('');
    setSearchText('');
    setCategorias([]); // limpiar artículos del negocio anterior del buscador
  }, [activeBizId]);

  useEffect(() => {
    if (!activeBizId) {
      setAgrupaciones([]);
      return;
    }
    refetchAgrupaciones();
  }, [activeBizId, activeDivisionId, reloadKey, refetchAgrupaciones]);

  // ── Fetch recetas-costos y article-price-config al cambiar de negocio ──
  // Las recetas se guardan siempre en el negocio principal (rootBusiness)
  useEffect(() => {
    if (!activeBizId) return;
    let alive = true;
    const recetasBizId = rootBusiness?.id ? Number(rootBusiness.id) : Number(activeBizId);
    const configBizId = Number(activeBizId);
    const orgId = organization?.id;

    Promise.all([
      RecetasAPI.getCostos(recetasBizId).catch(() => ({ costos: {} })),
      PriceConfigAPI.getAll(configBizId).catch(() => ({ byArticle: {}, byRubro: {}, byAgrupacion: {} })),
      fetch(`${BASE}/businesses/${configBizId}/articles-alertas-ventas`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token') || ''}`, 'X-Business-Id': String(configBizId) },
      }).then(r => r.json()).catch(() => ({ hayAlerta: false })),
      orgId ? getOrgPriceListConfig(orgId).catch(() => []) : Promise.resolve([]),
    ]).then(([costosRes, configRes, alertaVentasRes, listsRes]) => {
      if (!alive) return;
      setRecetasCostos(costosRes?.costos || {});
      setPriceConfig({ byArticle: configRes?.byArticle || {}, byRubro: configRes?.byRubro || {}, byAgrupacion: configRes?.byAgrupacion || {} });
      setAlertaVentas(alertaVentasRes || null);
      if (Array.isArray(listsRes) && listsRes.length > 0) setAllPriceLists(listsRes);
    });

    return () => { alive = false; };
  }, [activeBizId]);

  const handleRecetaSaved = useCallback(async (savedReceta) => {
    if (!savedReceta?.article_id) return;

    // Actualizar el artículo que se editó inmediatamente
    setRecetasCostos(prev => ({
      ...prev,
      [String(savedReceta.article_id)]: {
        costoTotal: savedReceta.costo_total,
        porciones: savedReceta.porciones || 1,
        tieneAlerta: savedReceta.tiene_alerta || false,
      },
    }));

    // Refetch completo de costos para capturar los artículos vinculados
    // que el backend acaba de actualizar via propagateRecipe
    try {
      const bizId = rootBusiness?.id ? Number(rootBusiness.id) : Number(activeBizId);
      const res = await RecetasAPI.getCostos(bizId);
      if (res?.costos) setRecetasCostos(res.costos);
    } catch (e) {
      console.warn('[handleRecetaSaved] refetch costos falló:', e.message);
    }
  }, [activeBizId, rootBusiness]);

  // ── Handler centralizado de guardado de price config ──
  const handlePriceConfigSave = React.useCallback((body) => {
    const bizId = Number(activeBizId);
    const doSave = async () => {
      try {
        const { _deleteIndividuales, _deleteObjetivo, _delete, _deleteManual, ...cleanBody } = body;

        if (_deleteObjetivo) {
          // Borrar objetivo de la agrupación
          await PriceConfigAPI.remove(bizId, { scope: body.scope, scopeId: body.scopeId });

          // Borrar objetivos individuales de todos los artículos
          if (Array.isArray(body.articleIds) && body.articleIds.length > 0) {
            await Promise.all(
              body.articleIds.map(artId =>
                PriceConfigAPI.remove(bizId, { scope: 'articulo', scopeId: String(artId) })
                  .catch(() => { })
              )
            );
          }
        } else if (_deleteManual) {
          await PriceConfigAPI.remove(bizId, { scope: body.scope, scopeId: body.scopeId });
        } else {
          await PriceConfigAPI.save(bizId, cleanBody);
        }

        const r = await PriceConfigAPI.getAll(bizId);
        setPriceConfig({
          byArticle: r?.byArticle || {},
          byRubro: r?.byRubro || {},
          byAgrupacion: r?.byAgrupacion || {},
        });
      } catch (e) {
        console.error('[handlePriceConfigSave]', e);
      }
    };
    doSave();
  }, [activeBizId, setPriceConfig]);

  // ── Bulk precioManual: un save por artículo + un solo getAll al final ──
  const handleBulkManualSave = React.useCallback(async (updates) => {
    const bizId = Number(activeBizId);
    if (!bizId || !updates?.length) return;
    try {
      const toSave = updates.filter(u => u.precioManual != null);
      const toDelete = updates.filter(u => u.precioManual == null);

      // Optimista
      setPriceConfig(prev => {
        const byArticle = { ...prev.byArticle };
        updates.forEach(({ artId, precioManual }) => {
          byArticle[String(artId)] = {
            ...(byArticle[String(artId)] || {}),
            precioManual: precioManual ?? null,
          };
        });
        return { ...prev, byArticle };
      });

      // Un solo request
      await PriceConfigAPI.bulkSave(bizId, {
        updates: toSave.map(({ artId, precioManual }) => ({ artId, precioManual })),
        deletes: toDelete.map(({ artId }) => ({ artId })),
      });

      const r = await PriceConfigAPI.getAll(bizId);
      setPriceConfig({
        byArticle: r?.byArticle || {},
        byRubro: r?.byRubro || {},
        byAgrupacion: r?.byAgrupacion || {},
      });
    } catch (e) {
      console.error('[handleBulkManualSave]', e);
    }
  }, [activeBizId, setPriceConfig]);

  // ── Escuchar cambios de config global — limpiar overrides locales ──
  React.useEffect(() => {
    const onConfigUpdated = (e) => {
      const { key } = e?.detail || {};
      // Cuando se guarda el costo ideal global, limpiar priceConfig local
      // para que la tabla refleje solo el global sin overrides
      if (key === 'articulos_costo_ideal') {
        setPriceConfig({ byArticle: {}, byRubro: {}, byAgrupacion: {} });
      }
    };
    window.addEventListener('config:updated', onConfigUpdated);
    return () => window.removeEventListener('config:updated', onConfigUpdated);
  }, []);
  React.useEffect(() => {
    const onUndo = async (e) => {
      const d = e?.detail;
      // Soportar ambos kinds por compatibilidad
      if (d?.kind !== 'objetivo_update' && d?.kind !== 'objetivo_change') return;
      const bizId = Number(activeBizId);

      // Si viene con payload directo (undo desde toast de tabla)
      if (d?.payload?.scope && d?.payload?.val != null) {
        const { scope, scopeId, valAnterior, articleIds } = d.payload;
        try {
          await PriceConfigAPI.save(bizId, {
            scope, scopeId,
            objetivo: valAnterior ?? null,
            articleIds, pisarTodo: true,
          });
          if (Array.isArray(articleIds) && articleIds.length > 0) {
            setPriceConfig(prev => {
              const byArticle = { ...prev.byArticle };
              articleIds.forEach(artId => {
                byArticle[String(artId)] = {
                  ...(byArticle[String(artId)] || {}),
                  objetivo: valAnterior ?? null,
                };
              });
              return { ...prev, byArticle };
            });
          }
          const r = await PriceConfigAPI.getAll(bizId);
          setPriceConfig({
            byArticle: r?.byArticle || {},
            byRubro: r?.byRubro || {},
            byAgrupacion: r?.byAgrupacion || {},
          });
        } catch (err) { console.error('[undo objetivo_change]', err); }
        return;
      }

      // Undo completo con snapshot previo
      const prevConfig = d?.payload?.prevConfig || prevConfigRef.current;
      if (!prevConfig) return;
      try {
        await PriceConfigAPI.remove(bizId, { scope: 'all' });
        const entries = [
          ...Object.entries(prevConfig.byArticle || {}).map(([id, v]) =>
            ({ scope: 'articulo', scopeId: id, objetivo: v.objetivo, precioManual: v.precioManual })),
          ...Object.entries(prevConfig.byRubro || {}).map(([id, v]) =>
            ({ scope: 'rubro', scopeId: id, objetivo: v.objetivo })),
          ...Object.entries(prevConfig.byAgrupacion || {}).map(([id, v]) =>
            ({ scope: 'agrupacion', scopeId: id, objetivo: v.objetivo })),
        ];
        await Promise.all(entries.map(e => PriceConfigAPI.save(bizId, e).catch(() => { })));
        const r = await PriceConfigAPI.getAll(bizId);
        setPriceConfig({
          byArticle: r?.byArticle || {},
          byRubro: r?.byRubro || {},
          byAgrupacion: r?.byAgrupacion || {},
        });
      } catch (err) { console.error('[undo objetivo_update]', err); }
    };
    window.addEventListener('ui:undo', onUndo);
    return () => window.removeEventListener('ui:undo', onUndo);
  }, [activeBizId, setPriceConfig]);



  const [todoInfo, setTodoInfo] = useState({
    todoGroupId: null,
    idsSinAgrupCount: 0,
    todoIds: new Set(),
  });

  const todoIdRef = useRef(null);
  useEffect(() => {
    todoIdRef.current = todoInfo?.todoGroupId ?? null;
  }, [todoInfo?.todoGroupId]);

  const handleTodoInfo = useCallback((info) => {
    const safe = info || {};
    const rawId = safe.todoGroupId;
    const todoGroupId = Number.isFinite(Number(rawId)) ? Number(rawId) : null;

    const idsSinAgrupArray = Array.isArray(safe.idsSinAgrup)
      ? safe.idsSinAgrup
      : [];

    const todoIdsSet = new Set(
      idsSinAgrupArray
        .map((v) => Number(v))
        .filter((n) => Number.isFinite(n) && n > 0)
    );

    const idsSinAgrupCount = Number.isFinite(Number(safe.idsSinAgrupCount))
      ? Number(safe.idsSinAgrupCount)
      : todoIdsSet.size;

    setTodoInfo({
      todoGroupId,
      idsSinAgrupCount,
      todoIds: todoIdsSet,
    });
  }, []);

  useEffect(() => {
    window.__DEBUG_VENTAS_MAP = ventasMap;

    if (ventasMap && ventasMap.size > 0) {
    }
  }, [ventasMap]);

  const totalBizAmount = useMemo(() => {
    if (!ventasMap || ventasMap.size === 0) return 0;
    let total = 0;
    for (const [, v] of ventasMap) {
      total += Number(v?.amount ?? 0);
    }
    return total;
  }, [ventasMap]);

  // ✅ CAMBIO 2: Guardar/cargar favorita por negocio
  useEffect(() => {
    const key = getFavKey(activeBizId);
    if (Number.isFinite(Number(favoriteGroupId))) {
      localStorage.setItem(key, String(favoriteGroupId));
    } else {
      localStorage.removeItem(key);
    }
  }, [favoriteGroupId, activeBizId]);

  const mutateGroups = useCallback(async (action) => {

    setAgrupaciones(prev => {
      switch (action.type) {
        case 'create':
          return applyCreateGroup(prev, {
            id: action.id,
            nombre: action.nombre,
            articulos: action.articulos
          });
        case 'append':
          return applyAppend(prev, {
            groupId: action.groupId,
            articulos: action.articulos,
            baseById: action.baseById
          });
        case 'remove':
          return applyRemove(prev, {
            groupId: action.groupId,
            ids: action.ids
          });
        case 'move':
          return applyMove(prev, {
            fromId: action.fromId,
            toId: action.toId,
            ids: action.ids,
            baseById: action.baseById
          });
        default:
          return prev;
      }
    });

    // Actualizar orgAssignedIds optimistamente para que idsSinAgrup se recalcule
    // sin esperar el refetch del backend.
    // - create / append / move→toId: agregar IDs a orgAssignedIds
    // - remove / move→fromId (Sin Agrupación): NO tocar orgAssignedIds
    //   (quitar de orgAssignedIds haría que reaparezcan en Sin Agrupación si vienen de otro subnegocio)
    setOrgAssignedIds(prev => {
      if (!Array.isArray(prev)) return prev;
      let toAdd = [];
      if (action.type === 'create') {
        toAdd = (action.articulos || []).map(a => Number(a?.id ?? a)).filter(n => n > 0);
      } else if (action.type === 'append') {
        toAdd = (action.articulos || []).map(a => Number(a?.id ?? a)).filter(n => n > 0);
      } else if (action.type === 'move') {
        toAdd = (action.ids || []).map(Number).filter(n => n > 0);
      }
      if (!toAdd.length) return prev;
      const prevSet = new Set(prev);
      const newIds = toAdd.filter(id => !prevSet.has(id));
      return newIds.length ? [...prev, ...newIds] : prev;
    });

    try { emitGroupsChanged(action.type, { action }); } catch { }
  }, []);

  useEffect(() => {
    if (!activeBizId) return;
    refetchAgrupaciones();
  }, [activeBizId, reloadKey, refetchAgrupaciones]);

  // Cargar favorita por negocio desde backend o localStorage
  useEffect(() => {
    const bid = activeBizId;
    if (!bid) {
      setFavoriteGroupId(null);
      return;
    }

    // ✅ Resetear inmediatamente al cambiar de negocio para evitar selección cruzada
    setFavoriteGroupId(null);

    (async () => {
      try {
        const res = await BusinessesAPI.getFavoriteGroup(bid);
        const favIdFromDb = Number(res?.favoriteGroupId);
        if (Number.isFinite(favIdFromDb) && favIdFromDb > 0) {
          setFavoriteGroupId(favIdFromDb);
        } else {
          const key = getFavKey(bid);
          const localFav = Number(localStorage.getItem(key));
          setFavoriteGroupId(Number.isFinite(localFav) ? localFav : null);
        }
      } catch (e) {
        console.error('Error cargando favorita desde backend', e);
        const key = getFavKey(bid);
        const localFav = Number(localStorage.getItem(key));
        setFavoriteGroupId(Number.isFinite(localFav) ? localFav : null);
      }
    })();
  }, [activeBizId]);

  const handleDownloadVentasCsv = async ({
    businessIdOverride = null,
    branchId = null,
    articleIds = null,    // Set<number> | { listId: number } | null
    listId = null,
  } = {}) => {
    try {
      const bid = businessIdOverride ?? activeBizId;
      const { from: rawFrom, to: rawTo } = periodo || {};
      // Garantizar YYYY-MM-DD
      const from = rawFrom ? String(rawFrom).slice(0, 10) : null;
      const to = rawTo ? String(rawTo).slice(0, 10) : null;

      if (!bid || !from || !to) {
        showAlert('Falta negocio activo o rango de fechas para descargar el CSV.', 'warning');
        return;
      }

      // Si articleIds es un objeto con listId (lista no cargada en memoria),
      // necesitamos cargar sus IDs desde el backend antes de exportar
      let resolvedArticleIds = null;
      if (articleIds instanceof Set) {
        resolvedArticleIds = articleIds;
      } else if (articleIds?.listId) {
        // Cargar IDs de la lista desde el backend
        try {
          const { ListsAPI } = await import('@/hooks/useArticleSelection');
          const res = await ListsAPI.getItems(String(bid), articleIds.listId);
          const ids = new Set((res?.items || []).map(i => Number(i.article_id)).filter(n => n > 0));
          resolvedArticleIds = ids.size > 0 ? ids : null;
        } catch (e) {
          console.warn('[handleDownloadVentasCsv] No se pudieron cargar IDs de lista:', e.message);

        }
      }

      const blob = await downloadVentasCSV(bid, {
        from,
        to,
        branchId,
        articleIds: resolvedArticleIds,
        businessIdOverride: businessIdOverride ? Number(businessIdOverride) : null,
      });

      if (!blob || blob.size === 0) {
        showAlert('El CSV vino vacío.', 'warning');
        return;
      }

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      const branchSuffix = branchId ? `_suc${branchId}` : '';
      const listSuffix = resolvedArticleIds ? '_lista' : '';
      a.href = url;
      a.download = `ventas_${bid}${branchSuffix}${listSuffix}_${from}_a_${to}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error al descargar CSV de ventas', err);
      showAlert(`Error al descargar CSV de ventas: ${err.message || err}`, 'error');
    }
  };

  // ── Descarga de ventas de una lista desde el sidebar ─────────────────────
  const handleDownloadList = useCallback(async (listId, listName) => {
    const bid = activeBizId;
    if (!bid || !periodo.from || !periodo.to) {
      showAlert('No hay periodo activo para descargar.', 'warning');
      return;
    }
    try {
      const { ListsAPI } = await import('@/hooks/useArticleSelection');
      const res = await ListsAPI.getItems(String(bid), listId);
      const ids = new Set(
        (res?.items || []).map(i => Number(i.article_id)).filter(n => n > 0)
      );

      if (ids.size === 0) {
        showAlert(`La lista "${listName}" no tiene artículos.`, 'warning');
        return;
      }

      const branchId = activeBranchFilter?.mode === 'main' ? 'main'
        : activeBranchFilter?.mode === 'branch' ? activeBranchFilter.branchId
          : null;

      const blob = await downloadVentasCSV(bid, {
        from: periodo.from,
        to: periodo.to,
        branchId,
        articleIds: ids,
      });

      if (!blob || blob.size === 0) {
        showAlert('No hay ventas en el periodo seleccionado para esta lista.', 'info');
        return;
      }

      const safeName = (listName || 'lista').replace(/[^a-zA-Z0-9_\-áéíóúüñÁÉÍÓÚÜÑ ]/g, '').trim();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ventas_${safeName}_${periodo.from}_a_${periodo.to}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);

      showAlert(`✓ Ventas de "${listName}" descargadas`, 'success');
    } catch (err) {
      console.error('handleDownloadList error:', err);
      showAlert(`Error al descargar la lista: ${err.message || err}`, 'error');
    }
  }, [activeBizId, periodo, activeBranchFilter, showAlert]);

  useEffect(() => {
    const onBizSynced = () => setReloadKey((k) => k + 1);

    const onVentasUpdated = () => {
      setSyncVersion((v) => v + 1);
    };

    // Banner de sincronización en curso
    const onSyncStart = (e) => {
      setIsSyncing(true);
      setSyncMsg('Sincronizando artículos con MaxiRest…');
    };
    const onSyncProgress = (e) => {
      const msg = e?.detail?.msg || '';
      if (msg) setSyncMsg(msg);
    };
    const onSyncCompleted = () => {
      setIsSyncing(false);
      setSyncMsg('');
      // Refrescar agrupaciones y artículos al finalizar la sync
      setReloadKey((k) => k + 1);
    };

    // Al montar: si el sync ya terminó mientras navegábamos, forzar reload
    // (syncDone se escribe en syncservice al finalizar syncAll)
    try {
      const bizId = localStorage.getItem('activeBusinessId');
      if (bizId) {
        const doneTs = sessionStorage.getItem(`lazarillo:syncDone:${bizId}`);
        if (doneTs) {
          sessionStorage.removeItem(`lazarillo:syncDone:${bizId}`);
          // Pequeño delay para que el componente termine de montar antes del reload
          setTimeout(() => setReloadKey((k) => k + 1), 300);
        }
      }
    } catch { }

    window.addEventListener('business:synced', onBizSynced);
    window.addEventListener('ventas:updated', onVentasUpdated);
    window.addEventListener('sync:start', onSyncStart);
    window.addEventListener('sync:progress', onSyncProgress);
    window.addEventListener('sync:completed', onSyncCompleted);

    return () => {
      window.removeEventListener('business:synced', onBizSynced);
      window.removeEventListener('ventas:updated', onVentasUpdated);
      window.removeEventListener('sync:start', onSyncStart);
      window.removeEventListener('sync:progress', onSyncProgress);
      window.removeEventListener('sync:completed', onSyncCompleted);
    };
  }, []);

  const activeBizRef = useRef(localStorage.getItem('activeBusinessId') || '');
  useEffect(() => {
    activeBizRef.current = activeBizId;
  }, [activeBizId]);

  useEffect(() => {
    if (!agrupacionSeleccionada) return;
    const gActual = (agrupaciones || []).find(g => Number(g.id) === Number(agrupacionSeleccionada.id));
    if (gActual && (
      gActual.nombre !== agrupacionSeleccionada.nombre ||
      (Array.isArray(gActual.articulos) ? gActual.articulos.length : 0) !==
      (Array.isArray(agrupacionSeleccionada.articulos) ? agrupacionSeleccionada.articulos.length : 0)
    )) {
      setAgrupacionSeleccionada(gActual);
    }
  }, [agrupaciones]);

  // Resetear categoriaSeleccionada SOLO cuando cambia el ID de la agrupacion
  // Usar ref para evitar que el efecto se dispare por re-renders del mismo objeto
  const prevAgrupacionIdRef = useRef(null);
  useEffect(() => {
    const newId = agrupacionSeleccionada?.id ?? null;
    if (String(newId) !== String(prevAgrupacionIdRef.current)) {
      prevAgrupacionIdRef.current = newId;
      setFiltroBusqueda('');
      setCategoriaSeleccionada(null);
      setActiveIds(new Set());
    }
  });

  useEffect(() => {
    if (!activeBizId) return;
    clearVentasCache();
    setSyncVersion(v => v + 1);
  }, [periodo.from, periodo.to, activeBizId, activeBranchFilter?.mode, activeBranchFilter?.branchId]);

  const handleCategoriasLoaded = useCallback((catsRaw) => {
    const normalizadas = (catsRaw || []).map((sub) => ({
      ...sub,
      categorias: (sub.categorias || []).map((cat) => ({
        ...cat,
        articulos: (cat.articulos || []).map((a) => {
          const idCanonico = getArtId(a);
          return {
            ...a,
            article_id: idCanonico,
            id: idCanonico ?? a.id,
          };
        }),
      })),
    }));

    setCategorias(normalizadas);
  }, []);

  const metaById = useMemo(() => {
    const m = new Map();
    (categorias || []).forEach(sub =>
      (sub.categorias || []).forEach(cat =>
        (cat.articulos || []).forEach(a => {
          const id = getArtId(a);
          if (id == null) return;
          m.set(id, {
            id,
            nombre: String(a.nombre ?? a.descripcion ?? `#${id}`),
            categoria: String(a.categoria ?? cat.categoria ?? 'Sin categoría'),
            subrubro: String(a.subrubro ?? sub.subrubro ?? 'Sin subrubro'),
            precio: Number(a.precio ?? 0),
          });
        })
      )
    );
    return m;
  }, [categorias]);

  const agrupacionesRich = useMemo(() => {
    return (agrupaciones || []).map(g => ({
      ...g,
      articulos: getGroupItemsRaw(g).map(a => {
        const id = getArtId(a);
        if (id == null) return null;
        const meta = metaById.get(id);
        return meta ? { ...a, ...meta, id } : { ...a, id };
      }).filter(Boolean),
    }));
  }, [agrupaciones, metaById]);

  const discGroup = useMemo(
    () => (agrupacionesRich || []).find(isDiscontinuadosGroup) || null,
    [agrupacionesRich]
  );

  const discIds = useMemo(() => {
    const s = new Set();
    if (!discGroup) return s;
    for (const art of getGroupItemsRaw(discGroup)) {
      const id = getArtId(art);
      if (id != null) s.add(id);
    }
    return s;
  }, [discGroup]);

  const [localDiscIds, setLocalDiscIds] = useState(() => new Set());
  const effectiveDiscIds = useMemo(() => {
    if (discIds.size > 0) return discIds;
    return localDiscIds;
  }, [discIds, localDiscIds]);

  // Modo organización: el principal solo tiene Sin Agrupacion/Discontinuados
  // y hay subnegocios creados (created_from === 'from_group')


  const articuloIds = useMemo(
    () =>
      (agrupacionSeleccionada?.articulos || [])
        .map((a) => Number(a?.id ?? a?.articuloId))
        .filter(Number.isFinite),
    [agrupacionSeleccionada]
  );

  const ventasMapFiltrado = useMemo(() => {
    if (!agrupacionSeleccionada?.id) return ventasMap;
    const s = new Set(articuloIds);
    const out = new Map();
    ventasMap.forEach((v, k) => {
      if (s.has(Number(k))) out.set(Number(k), v);
    });
    return out;
  }, [ventasMap, agrupacionSeleccionada, articuloIds]);

  const getAmountForId = useCallback((id) => {
    const k = Number(id);
    if (!Number.isFinite(k) || k <= 0) return 0;

    try {
      const { qty, amount } = getVentasFromMap(ventasMap, k);
      if (Number.isFinite(Number(amount)) && Number(amount) !== 0) {
        return Number(amount);
      }
      const precio = metaById.get(k)?.precio ?? 0;
      return Number(qty || 0) * Number(precio || 0);
    } catch (e) {
      return 0;
    }
  }, [ventasMap, metaById]);

  const getQtyForId = useCallback(
    (id) => {
      const k = Number(id);
      if (!Number.isFinite(k) || k <= 0) return 0;
      const { qty } = getVentasFromMap(ventasMap, k);
      return Number(qty || 0);
    },
    [ventasMap]
  );

  const getGroupQty = useCallback(
    (g) => {
      const items = getGroupItemsRaw(g);
      if (!items.length) return 0;
      let total = 0;
      for (const a of items) {
        const id = Number(a?.id ?? a?.articuloId);
        total += getQtyForId(id);
      }
      return total;
    },
    [getQtyForId]
  );

  const getGroupAmount = useCallback(
    (g) => {
      const items = getGroupItemsRaw(g);
      if (!items.length) return 0;
      let total = 0;
      for (const a of items) {
        const id = Number(a?.id ?? a?.articuloId);
        total += getAmountForId(id);
      }
      return Number(total || 0);
    },
    [getAmountForId]
  );

  const agrupacionesOrdenadas = useMemo(() => {
    const list = Array.isArray(agrupacionesRich) ? [...agrupacionesRich] : [];

    const todoId = todoInfo?.todoGroupId ? Number(todoInfo.todoGroupId) : null;

    return list.sort((a, b) => {
      const ida = Number(a.id);
      const idb = Number(b.id);

      const isTodoA = todoId && ida === todoId;
      const isTodoB = todoId && idb === todoId;
      if (isTodoA && !isTodoB) return -1;
      if (!isTodoA && isTodoB) return 1;

      const discA = isDiscontinuadosGroup(a);
      const discB = isDiscontinuadosGroup(b);
      if (discA && !discB) return 1;
      if (!discA && discB) return -1;

      const ma = getGroupAmount(a);
      const mb = getGroupAmount(b);
      if (mb !== ma) return mb - ma;

      return String(a.nombre || '').localeCompare(String(b.nombre || ''));
    });
  }, [agrupacionesRich, todoInfo?.todoGroupId, getGroupAmount]);

  useEffect(() => {
    if (!agrupacionSeleccionada) return;
    const enriched = (agrupacionesRich || []).find(
      g => Number(g.id) === Number(agrupacionSeleccionada.id)
    );
    if (enriched) setAgrupacionSeleccionada(enriched);
  }, [agrupacionesRich]);

  useEffect(() => {
    if (!periodo?.from || !periodo?.to) return;
    setSyncVersion((v) => v + 1);
  }, [periodo?.from, periodo?.to]);


  const handleTotalResolved = useCallback((id, total) => {
    const key = Number(id);
    if (!Number.isFinite(key) || key <= 0) return;

    const qty = Number(total?.qty ?? total?.total ?? 0);
    const amount = Number(
      total?.amount ??
      total?.calcAmount ??
      total?.total_amount ??
      total?.totalAmount ??
      0
    );

    const qtyOk = Number.isFinite(qty) ? qty : 0;
    const amountOk = Number.isFinite(amount) ? amount : 0;

    if (qtyOk === 0 && amountOk === 0) return;

    setVentasOverrides(prev => {
      const next = new Map(prev);
      const prevVal = next.get(key) || {};

      if ((prevVal.qty ?? 0) === qtyOk && (prevVal.amount ?? 0) === amountOk) return prev;

      next.set(key, { ...prevVal, qty: qtyOk, amount: amountOk });
      return next;
    });
  }, []);


  const [jumpToId, setJumpToId] = useState(null);
  const [selectedArticleId, setSelectedArticleId] = useState(null);
  const pendingJumpRef = useRef(null);
  const jumpTriesRef = useRef(0);

  const tryJumpNow = useCallback((id) => {
    const container = document.getElementById('tabla-scroll');
    const row = document.querySelector(`[data-article-id="${id}"]`);
    if (!container || !row) return false;
    const top = row.offsetTop - container.clientHeight / 2;
    container.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
    row.classList.add('highlight-jump');
    setTimeout(() => row.classList.remove('highlight-jump'), 1400);
    return true;
  }, []);

  const scheduleJump = useCallback((id) => {
    pendingJumpRef.current = Number(id);
    jumpTriesRef.current = 0;
  }, []);

  const allIds = useMemo(() => {
    const out = [];
    for (const sub of categorias || []) {
      for (const cat of sub.categorias || []) {
        for (const a of cat.articulos || []) {
          const id = getArtId(a);
          if (id != null) out.push(id);
        }
      }
    }
    return out;
  }, [categorias]);

  const idsAsignados = useMemo(() => {
    const s = new Set();

    (agrupaciones || [])
      .filter(g => !isRealTodoGroup(g, todoInfo?.todoGroupId))
      .forEach(g => getGroupItemsRaw(g).forEach(a => {
        const id = getArtId(a);
        if (id != null) s.add(id);
      }));

    return s;
  }, [agrupaciones, todoInfo?.todoGroupId]);

  const todoIdsFromTree = useMemo(() => {
    const s = new Set();
    for (const id of allIds) {
      if (!idsAsignados.has(id)) {
        s.add(id);
      }
    }
    return s;
  }, [allIds, idsAsignados]);

  const visibleIds = useMemo(() => {
    const sel = agrupacionSeleccionada;
    if (!sel) return null;

    if (isDiscontinuadosGroup(sel)) {
      return discIds;
    }

    const todoId = todoInfo?.todoGroupId;

    if (isRealTodoGroup(sel, todoId) || esTodoGroupByName(sel)) {
      const countFromBackend = todoInfo?.idsSinAgrupCount ?? -1;
      if (countFromBackend === 0) return new Set();

      const base =
        (todoInfo?.todoIds && todoInfo.todoIds.size)
          ? todoInfo.todoIds
          : todoIdsFromTree;

      const out = new Set();
      for (const id of base) {
        const n = Number(id);
        if (!Number.isFinite(n) || n <= 0) continue;
        if (discIds.has(n)) continue;
        out.add(n);
      }
      return out;
    }

    const s = new Set();
    const selFresh = (agrupaciones || []).find(g => Number(g.id) === Number(sel.id)) || sel;
    const items = getGroupItemsRaw(selFresh);
    for (const a of items) {
      const id = getArtId(a);
      if (id == null) continue;
      if (discIds.has(id)) continue;
      s.add(id);
    }
    return s;
  }, [agrupacionSeleccionada, agrupaciones, todoInfo, todoIdsFromTree, discIds]);

  // Si hay lista activa en el sidebar → usar esos IDs como filtro
  const effectiveVisibleIds = useMemo(() => {
    if (activeListId && activeListItems instanceof Set && activeListItems.size > 0) {
      return activeListItems;
    }
    return visibleIds;
  }, [activeListId, activeListItems, visibleIds]);

  const focusArticle = useCallback(
    (rawId, preferGroupId = null) => {
      const id = Number(rawId);
      if (!Number.isFinite(id) || id <= 0) return;

      const alreadyVisible = !visibleIds || visibleIds.has(id);

      const groupsSet = agIndex.byArticleId.get(id) || new Set();
      const allGroups = agrupacionesRich || [];

      let targetGroupId = null;

      if (preferGroupId != null) {
        const prefNum = Number(preferGroupId);
        if (Number.isFinite(prefNum)) {
          const exists = allGroups.some(g => Number(g.id) === prefNum);
          if (exists) {
            targetGroupId = prefNum;
          }
        }
      }

      const normN = (v) => String(v || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
      const esGlobalGroup = (gid) => {
        const g = allGroups.find(x => Number(x.id) === Number(gid));
        const n = normN(g?.nombre);
        return n === 'sin agrupacion' || n === 'discontinuados' || n === 'descontinuados';
      };

      // En focusArticle, reemplazar el bloque de resolución de targetGroupId:

      if (!targetGroupId) {
        if (groupsSet.size > 0) {
          let discGroupId = null;
          let todoGroupIdFound = null;
          let realGroupId = null;

          for (const gid of groupsSet) {
            const n = Number(gid);
            if (!Number.isFinite(n)) continue;
            const g = allGroups.find(x => Number(x.id) === n);
            const nombre = normN(g?.nombre || '');
            if (nombre === 'discontinuados' || nombre === 'descontinuados') {
              discGroupId = n;
            } else if (nombre === 'sin agrupacion') {
              todoGroupIdFound = n;
            } else {
              realGroupId = n; // guardar pero no romper el loop
            }
          }

          // Discontinuados tiene MÁXIMA prioridad
          targetGroupId = discGroupId ?? realGroupId ?? todoGroupIdFound ?? Number([...groupsSet][0]);
        } else if (alreadyVisible) {
          targetGroupId = agrupacionSeleccionada?.id ?? null;
        } else if (Number.isFinite(Number(todoInfo?.todoGroupId))) {
          targetGroupId = Number(todoInfo.todoGroupId);
        }
      }

      if (
        targetGroupId &&
        (!agrupacionSeleccionada || Number(agrupacionSeleccionada.id) !== Number(targetGroupId))
      ) {
        const targetGroup =
          allGroups.find(g => Number(g.id) === Number(targetGroupId)) ||
          { id: targetGroupId, nombre: 'TODO', articulos: [] };

        try { markManualPick(); } catch { }

        setAgrupacionSeleccionada(targetGroup);
        setCategoriaSeleccionada(null);
        setFiltroBusqueda('');
      }

      setSelectedArticleId(id);
      setJumpToId(id);
      scheduleJump(id);

      setTimeout(() => {
        setJumpToId(null);
      }, 800);
    },
    [
      visibleIds,
      agIndex,
      todoInfo?.todoGroupId,
      agrupacionSeleccionada,
      agrupacionesRich,
      markManualPick,
      setAgrupacionSeleccionada,
      setCategoriaSeleccionada,
      setFiltroBusqueda,
      scheduleJump,
    ]
  );

  const handleDiscontinuadoChange = useCallback(
    async (rawId, isNowDiscontinuado, opts = {}) => {
      const id = Number(rawId);
      if (!Number.isFinite(id) || id <= 0) return;

      try {
        await refetchAgrupaciones();
      } catch (e) {
        console.error('Error refrescando agrupaciones:', e);
      }

      if (isNowDiscontinuado) {
        showMiss(`Artículo discontinuado correctamente`);
      } else {
        showMiss(`Artículo reactivado correctamente`);
      }
    },
    [refetchAgrupaciones, showMiss]
  );

  useEffect(() => {
    const onUndo = async (ui) => {
      const kind = ui.detail.kind;
      const scope = ui.detail.scope;
      const payload = ui.detail.payload || {};

      if (kind !== 'discontinue' || scope !== 'articulo') return;

      const ids = payload?.ids || [];
      const prev = payload?.undo?.payload?.prev || {};
      const wasInDiscontinuados = prev.wasInDiscontinuados === true;
      const discontinuadosGroupId = Number(prev.discontinuadosGroupId);
      const fromGroupId = Number(prev.fromGroupId);

      // ✅ Los grupos de Discontinuados y los originales viven en el principal
      // Usar el rootBusinessId para las llamadas HTTP del UNDO
      const rootBizId = rootBusiness?.id ? Number(rootBusiness.id) : null;

      if (!ids.length) {
        showMiss('No hay artículos para deshacer');
        return;
      }

      try {
        if (wasInDiscontinuados) {
          if (!Number.isFinite(discontinuadosGroupId) || discontinuadosGroupId <= 0) {
            showMiss('No se encontró el grupo Discontinuados');
            return;
          }

          await httpBiz(`/agrupaciones/${discontinuadosGroupId}/articulos`, {
            method: 'PUT',
            body: { ids },
          }, rootBizId);

          mutateGroups({
            type: 'append',
            groupId: discontinuadosGroupId,
            articulos: ids.map(id => ({ id })),
            baseById: metaById,
          });

          const label = ids.length === 1 ? 'Artículo devuelto' : `${ids.length} artículos devueltos`;
          showMiss(`${label} a Discontinuados`);

        } else {
          if (!Number.isFinite(fromGroupId) || fromGroupId <= 0) {
            for (const id of ids) {
              try {
                await httpBiz(`/agrupaciones/${discontinuadosGroupId}/articulos/${id}`, {
                  method: 'DELETE',
                }, rootBizId);
              } catch (e) {
                console.error(`Error quitando ${id} de Discontinuados:`, e);
              }
            }

            mutateGroups({
              type: 'remove',
              groupId: discontinuadosGroupId,
              ids,
            });

            const label = ids.length === 1 ? 'Artículo reactivado' : `${ids.length} artículos reactivados`;
            showMiss(label);

          } else {
            await httpBiz(`/agrupaciones/${fromGroupId}/articulos`, {
              method: 'PUT',
              body: { ids },
            }, rootBizId);

            for (const id of ids) {
              try {
                await httpBiz(`/agrupaciones/${discontinuadosGroupId}/articulos/${id}`, {
                  method: 'DELETE',
                }, rootBizId);
              } catch { }
            }

            mutateGroups({
              type: 'move',
              fromId: discontinuadosGroupId,
              toId: fromGroupId,
              ids,
              baseById: metaById,
            });

            const label = ids.length === 1 ? 'Artículo devuelto' : `${ids.length} artículos devueltos`;
            showMiss(`${label} a su grupo original`);
          }
        }

        // ✅ Refetch diferido: dar tiempo a la escritura en backend antes de recargar
        // El estado ya se actualizó optimistamente con mutateGroups arriba
        setTimeout(() => { refetchAgrupaciones().catch(() => { }); }, 1200);

      } catch (error) {
        console.error('[UNDO discontinue] Error:', error);
        showMiss('Error al deshacer: ' + error.message);
      }
    };

    window.addEventListener('ui:undo', onUndo);
    return () => window.removeEventListener('ui:undo', onUndo);
  }, [
    activeBizId,
    showMiss,
    refetchAgrupaciones,
    mutateGroups,
    metaById,
    rootBusiness,
  ]);

  useEffect(() => {
    const handler = (e) => {
      if (e.detail?.lists) setAllPriceLists(e.detail.lists);
    };
    window.addEventListener('pricelists:updated', handler);
    return () => window.removeEventListener('pricelists:updated', handler);
  }, []);

  const handleDiscontinuarBloque = useCallback(
    async (idsRaw = []) => {
      const ids = (idsRaw || [])
        .map(Number)
        .filter(n => Number.isFinite(n) && n > 0);

      if (!ids.length) return;

      if (!discGroup || !discGroup.id) {
        showAlert('No existe la agrupación "Discontinuados". Creala primero.', 'warning');
        return;
      }

      const ok = await showConfirm(
        `¿Marcar como DISCONTINUADOS ${ids.length} artículo(s) de este bloque?`
      );
      if (!ok) return;

      try {
        // Si discGroup es global (vive en el principal), usar su businessId
        const discBizId = discGroup.principal_business_id
          ? Number(discGroup.principal_business_id)
          : null;

        await httpBiz(`/agrupaciones/${discGroup.id}/articulos`, {
          method: 'PUT',
          body: { ids },
        }, discBizId);

        mutateGroups({
          type: 'append',
          groupId: Number(discGroup.id),
          articulos: ids.map(id => ({ id })),
          baseById: metaById,
        });

        showMiss(`Bloque discontinuado (${ids.length} artículo/s).`);
      } catch (e) {
        console.error('DISCONTINUAR_BLOQUE_ERROR', e);
        showAlert('No se pudo discontinuar el bloque.', 'error');
      }
    },
    [
      discGroup,
      mutateGroups,
      metaById,
      showMiss,
    ]
  );

  useEffect(() => {
    const id = Number(pendingJumpRef.current);
    if (!Number.isFinite(id) || id <= 0) return;

    const tick = () => {
      if (tryJumpNow(id)) {
        pendingJumpRef.current = null;
        return;
      }
      jumpTriesRef.current = 1;
      if (jumpTriesRef.current > 25) {
        pendingJumpRef.current = null;
        return;
      }
      setTimeout(tick, 80);
    };

    const t0 = setTimeout(tick, 40);
    return () => clearTimeout(t0);
  }, [
    categorias,
    agrupacionSeleccionada,
    reloadKey,
    ventasMapFiltrado,
    tryJumpNow
  ]);

  const todoGroupId = todoInfo?.todoGroupId || null;

  const nameById = useMemo(() => {
    const m = new Map();
    (categorias || []).forEach(sub =>
      (sub.categorias || []).forEach(cat =>
        (cat.articulos || []).forEach(a => {
          const id = getArtId(a);
          if (id == null) return;
          m.set(id, String(a.nombre || '').trim());
        })
      )
    );
    return m;
  }, [categorias]);

  useEffect(() => {
    const catsReady = Array.isArray(categorias) && categorias.length > 0;
    if (!agrupacionSeleccionada && todoGroupId && catsReady) {
      setAgrupacionSeleccionada({ id: Number(todoGroupId), nombre: 'TODO', articulos: [] });
      setFiltroBusqueda('');
      setCategoriaSeleccionada(null);
    }
  }, [todoGroupId, agrupacionSeleccionada, categorias]);

  // IDs que pertenecen al negocio activo.
  // orgAssignedIds = artículos asignados en agrupaciones de TODA la org (incluye otros subnegocios).
  // idsEnAgrupacionesLocales = artículos en las agrupaciones del negocio activo.
  // Un artículo pertenece a este negocio si:
  //   - está en sus agrupaciones locales, O
  //   - NO está asignado a ningún subnegocio (está en sin agrupar del principal)
  const idsNegocioActivo = useMemo(() => {
    const normNombre = (v) => String(v || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
    const esGlobal = (g) => {
      const n = normNombre(g?.nombre);
      return n === 'sin agrupacion' || n === 'discontinuados' || n === 'descontinuados';
    };

    const rootBizId = rootBusiness?.id ? Number(rootBusiness.id) : null;
    const isFromGroup = rootBizId && Number(activeBizId) !== rootBizId;

    const s = new Set();

    if (isFromGroup) {
      // SUBNEGOCIO: solo articulos de sus agrupaciones propias (excluye globales inyectados)
      // Lee tanto articulos JSONB como app_articles_ids
      for (const g of agrupaciones || []) {
        if (esGlobal(g)) continue;
        for (const a of getGroupItemsRaw(g)) {
          const id = getArtId(a);
          if (id != null) s.add(id);
        }
        const appIds = Array.isArray(g.app_articles_ids) ? g.app_articles_ids : [];
        for (const raw of appIds) { const n = Number(raw); if (n > 0) s.add(n); }
      }
      // Tambien incluir los de Sin Agrupacion y Discontinuados globales
      for (const g of agrupaciones || []) {
        if (!esGlobal(g)) continue;
        for (const a of getGroupItemsRaw(g)) {
          const id = getArtId(a);
          if (id != null) s.add(id);
        }
        const appIds = Array.isArray(g.app_articles_ids) ? g.app_articles_ids : [];
        for (const raw of appIds) { const n = Number(raw); if (n > 0) s.add(n); }
      }
      if (todoInfo?.todoIds?.size) {
        for (const id of todoInfo.todoIds) { const n = Number(id); if (n > 0) s.add(n); }
      }
    } else {
      // PRINCIPAL: artículos propios = los del árbol que NO están asignados a subnegocios
      // "Asignados a subnegocios" = orgAssignedIds MENOS los que están en agrupaciones del propio principal
      if (Array.isArray(orgAssignedIds) && orgAssignedIds.length > 0) {
        // IDs en agrupaciones propias del principal (no globales)
        const enAgrupacionesPropias = new Set();
        for (const g of agrupaciones || []) {
          if (esGlobal(g)) continue;
          for (const a of getGroupItemsRaw(g)) {
            const id = getArtId(a);
            if (id != null) enAgrupacionesPropias.add(id);
          }
          const appIds = Array.isArray(g.app_articles_ids) ? g.app_articles_ids : [];
          for (const raw of appIds) { const n = Number(raw); if (n > 0) enAgrupacionesPropias.add(n); }
        }
        // Asignados a subnegocios = orgAssignedIds que NO están en las agrupaciones del principal
        const asignadosSoloASubnegocios = new Set(
          orgAssignedIds.map(Number).filter(n => n > 0 && !enAgrupacionesPropias.has(n))
        );
        for (const [id] of nameById.entries()) {
          if (!asignadosSoloASubnegocios.has(id)) s.add(id);
        }
      } else {
        // Sin org o sin datos: todos los articulos
        for (const [id] of nameById.entries()) s.add(id);
      }
    }

    return s;
  }, [agrupaciones, orgAssignedIds, todoInfo?.todoIds, nameById, activeBizId, rootBusiness]);

  // IDs de artículos de la agrupación seleccionada (para pasar al sidebar con el objetivo)
  const agrupacionArticuloIds = useMemo(() => {
    if (!agrupacionSeleccionada) return [];
    const ids = new Set();
    const arts = Array.isArray(agrupacionSeleccionada.articulos) ? agrupacionSeleccionada.articulos : [];
    for (const a of arts) {
      const id = Number(a?.id ?? a?.article_id ?? a);
      if (id > 0) ids.add(id);
    }
    const appIds = Array.isArray(agrupacionSeleccionada.app_articles_ids)
      ? agrupacionSeleccionada.app_articles_ids
      : [];
    for (const raw of appIds) { const n = Number(raw); if (n > 0) ids.add(n); }
    return Array.from(ids);
  }, [agrupacionSeleccionada]);

  // Opciones del buscador: todos los articulos de todas las agrupaciones del negocio activo
  const opcionesBuscador = useMemo(() => {
    const seen = new Set();
    const result = [];

    for (const g of agrupacionesRich || []) {
      for (const a of (g.articulos || [])) {
        const id = Number(a?.id);
        if (!id || id <= 0 || seen.has(id)) continue;

        // ← CAMBIO: incluir si pertenece al negocio activo O si está en Discontinuados
        const esDiscontinuado = isDiscontinuadosGroup(g);
        if (!idsNegocioActivo.has(id) && !esDiscontinuado) continue;

        seen.add(id);
        const nombre = a?.nombre && !String(a.nombre).startsWith('#')
          ? String(a.nombre)
          : (metaById.get(id)?.nombre || nameById.get(id) || `#${id}`);
        result.push({ id, nombre, codigo: String(id) });
      }
    }

    // También incluir artículos de Sin Agrupación
    const sinAgrupIds = todoInfo?.todoIds?.size ? todoInfo.todoIds : todoIdsFromTree;
    for (const rawId of sinAgrupIds) {
      const id = Number(rawId);
      if (!id || id <= 0 || seen.has(id)) continue;
      if (!idsNegocioActivo.has(id)) continue;
      seen.add(id);
      const nombre = metaById.get(id)?.nombre || nameById.get(id) || `#${id}`;
      result.push({ id, nombre, codigo: String(id) });
    }

    return result;
  }, [agrupacionesRich, nameById, metaById, todoInfo?.todoIds, todoIdsFromTree, idsNegocioActivo]);

  const labelById = useMemo(() => {
    const m = new Map();
    (categorias || []).forEach(sub =>
      (sub.categorias || []).forEach(cat =>
        (cat.articulos || []).forEach(a => {
          const id = getArtId(a);
          if (id == null) return;
          m.set(id, String(a.nombre || '').trim());
        })
      )
    );
    return m;
  }, [categorias]);

  // Callbacks estables para SubBusinessCreateModal
  // Definidos con useCallback para evitar re-renders del modal que bloqueen los inputs
  const handleSubBizClose = useCallback(() => {
    setSubBizModalOpen(false);
    setGroupForSubBiz(null);
  }, []);

  const handleSubBizCreated = useCallback((newBiz) => {
    showMiss(`Sub-negocio "${newBiz.name}" creado`);
    setSubBizModalOpen(false);
    setGroupForSubBiz(prev => {
      if (prev?.id) {
        mutateGroups({ type: 'remove_group', groupId: Number(prev.id) });
      }
      return null;
    });
    refetchAgrupaciones();
  }, [showMiss, mutateGroups, refetchAgrupaciones]);

  const handleNeedOrgName = useCallback(() => {
    setOrgNameInput('');
    setOrgNameModalOpen(true);
  }, []);

  const handleGroupCreated = useCallback((nombre, id, articulos) => {
    mutateGroups({
      type: 'create',
      id: Number(id),
      nombre,
      articulos: Array.isArray(articulos) ? articulos : [],
    });
    setFiltroBusqueda('');
    setCategoriaSeleccionada(null);
  }, [mutateGroups]);

  // Ref para leer agrupacionSeleccionada sin que sea una dep del efecto
  const agrupSelRef = useRef(agrupacionSeleccionada);
  useEffect(() => { agrupSelRef.current = agrupacionSeleccionada; }, [agrupacionSeleccionada]);

  // Selección inteligente: Sin Agrupación tiene prioridad AL CARGAR, luego no interrumpe
  useEffect(() => {
    const todoId = todoInfo?.todoGroupId;
    const todoCount = todoInfo?.idsSinAgrupCount || 0;
    const todoEmpty = todoCount === 0;

    const catsReady = Array.isArray(categorias) && categorias.length > 0;
    const groupsReady = Array.isArray(agrupacionesRich) && agrupacionesRich.length > 0;
    if (!catsReady || !groupsReady) return;

    const currentSel = agrupSelRef.current;

    if (currentSel && isDiscontinuadosGroup(currentSel)) return;

    // ── Si ya hay una agrupación real seleccionada y válida → no tocar ──
    // Esto evita que cualquier mutación que cambie agrupacionesRich fuerce
    // la navegación a Sin Agrupación mientras el usuario está trabajando.
    const selEsAgrupacionReal = currentSel &&
      !isDiscontinuadosGroup(currentSel) &&
      todoId && Number(currentSel.id) !== Number(todoId) &&
      (agrupacionesRich || []).some(g => Number(g.id) === Number(currentSel.id));

    if (selEsAgrupacionReal) return;

    // ── Sin Agrupación tiene artículos y no hay nada seleccionado → ir a TODO ──
    if (!todoEmpty && todoId) {
      const isTodoSelected = currentSel && Number(currentSel.id) === Number(todoId);
      if (!isTodoSelected) {
        setAgrupacionSeleccionada({ id: Number(todoId), nombre: 'TODO', articulos: [] });
        setCategoriaSeleccionada(null);
        setFiltroBusqueda('');
      }
      return;
    }

    // ── Sin Agrupación vacío → favorita o primera ──
    if (todoEmpty && favoriteGroupId) {
      const fav = (agrupacionesRich || []).find(
        (g) => Number(g?.id) === Number(favoriteGroupId)
      );

      if (fav) {
        const selExistsInList = currentSel &&
          (agrupacionesRich || []).some(g => Number(g.id) === Number(currentSel.id));

        if (!selExistsInList) {
          setAgrupacionSeleccionada(fav);
          setCategoriaSeleccionada(null);
          setFiltroBusqueda('');
        }
      } else {
        setFavoriteGroupId(null);
      }
    }
  }, [
    activeBizId,
    todoInfo?.todoGroupId,
    todoInfo?.idsSinAgrupCount,
    favoriteGroupId,
    agrupacionesRich,
    categorias,
    setAgrupacionSeleccionada,
    setCategoriaSeleccionada,
    setFiltroBusqueda,
  ]);

  const handleSetFavorite = useCallback((groupId) => {
    setFavoriteGroupId((prev) => {
      const prevNum = Number(prev);
      const nextNum = Number(groupId);

      const final = prevNum === nextNum ? null : nextNum;

      const bid =
        activeBizRef.current ||
        activeBizId ||
        localStorage.getItem('activeBusinessId') ||
        null;

      if (bid) {
        (async () => {
          try {
            await BusinessesAPI.saveFavoriteGroup(bid, final);
          } catch (e) {
            console.error('Error guardando favorita en backend', e);
          }
        })();
      }
      return final;
    });
  }, [activeBizId]);

  const handleDeleteGroup = useCallback(async (group) => {
    if (!group || !group.id) return;
    if (
      Number(group.id) === Number(todoInfo?.todoGroupId) ||
      isDiscontinuadosGroup(group)
    ) {
      return;
    }
    const ok = await showConfirm(`¿Eliminar la agrupación "${group.nombre}"? Esta acción no se puede deshacer.`, { danger: true });
    if (!ok) return;

    try {
      await eliminarAgrupacion(group);

      // ✅ NO emitir aquí, SidebarCategorias ya lo hace

      await refetchAgrupaciones();
      if (Number(agrupacionSeleccionada?.id) === Number(group.id)) {
        setAgrupacionSeleccionada(null);
      }
    } catch (e) {
      console.error('Error al eliminar agrupación', e);
    }
  }, [todoInfo?.todoGroupId, refetchAgrupaciones, agrupacionSeleccionada]);

  const handleRenameGroup = useCallback(async (group) => {
    if (!group) return null;

    const currentName = String(group.nombre || '');
    const isTodo = esTodoGroup(group);
    const isDisc = isDiscontinuadosGroup(group);

    if (isDisc) return null;

    const promptMsg = isTodo
      ? 'Nombre para la nueva agrupación (los artículos de "Sin Agrupación" se moverán aquí):'
      : 'Nuevo nombre para la agrupación:';

    const nuevo = await showPrompt(promptMsg, isTodo ? '' : currentName);
    if (nuevo == null) return null;
    const nombre = nuevo.trim();
    if (!nombre) return null;
    if (!isTodo && nombre === currentName) return null;

    try {
      if (isTodo) {
        const baseSet =
          todoInfo?.todoIds && todoInfo.todoIds.size
            ? todoInfo.todoIds
            : todoIdsFromTree;

        const ids = Array.from(baseSet)
          .map(Number)
          .filter((n) => Number.isFinite(n) && n > 0);

        if (!ids.length) {
          showAlert('No hay artículos en "Sin agrupación" para capturar.', 'warning');
          return null;
        }

        const res = await httpBiz('/agrupaciones/create-or-move', {
          method: 'POST',
          body: {
            nombre,
            ids,
          },
        });

        const createdId = Number(
          res?.id || res?.groupId || res?.agrupacionId || res?.agrupacion?.id
        );

        const list = await refetchAgrupaciones();

        let nueva = null;
        if (Number.isFinite(createdId) && createdId > 0) {
          nueva = (list || []).find((g) => Number(g.id) === createdId) || null;
        }
        if (!nueva) {
          const wanted = nombre.toLowerCase();
          nueva =
            (list || []).find(
              (g) => String(g.nombre || '').toLowerCase() === wanted
            ) || null;
        }

        if (nueva) {
          try { markManualPick(); } catch { }
          setAgrupacionSeleccionada(nueva);
          setCategoriaSeleccionada(null);
          setFiltroBusqueda('');
        }

        // ✅ NO emitir aquí, SidebarCategorias ya lo hace
        showMiss(`Agrupación "${nombre}" creada a partir de "Sin agrupación".`);

        return null;

      } else {
        await actualizarAgrupacion(activeBizId, group.id, { nombre });
        await refetchAgrupaciones();
        showMiss('Nombre de agrupación actualizado.');

        // ✅ Devolver objeto para que SidebarCategorias emita
        return { newName: nombre };
      }
    } catch (e) {
      console.error('RENAME_GROUP_ERROR', e);
      showAlert('No se pudo renombrar la agrupación.', 'error');
      return null;
    }
  }, [
    activeBizId,
    todoInfo,
    todoIdsFromTree,
    refetchAgrupaciones,
    setAgrupacionSeleccionada,
    setCategoriaSeleccionada,
    setFiltroBusqueda,
    showMiss,
    markManualPick
  ]);

  const effectiveViewMode = useMemo(() => {
    const g = agrupacionSeleccionada;
    if (g?.id && viewModeByGroup) {
      // Buscar tanto por numero como por string por si las keys difieren
      const saved = viewModeByGroup[Number(g.id)] || viewModeByGroup[String(g.id)];
      if (saved === 'by-subrubro' || saved === 'by-categoria') return saved;
    }
    return viewModeGlobal;
  }, [agrupacionSeleccionada, viewModeByGroup, viewModeGlobal]);

  const sidebarListMode = effectiveViewMode;
  const tableHeaderMode =
    effectiveViewMode === 'by-subrubro' ? 'cat-first' : 'sr-first';

  const modalTreeMode = 'cat-first';

  const filtroEfectivo = useMemo(
    () => (filtroBusqueda || ''),
    [filtroBusqueda]
  );

  const ventasPorArticuloMerged = useMemo(() => {
    const base = ventasMap || new Map();
    if (!ventasOverrides || ventasOverrides.size === 0) return base;

    const merged = new Map(base);
    for (const [id, ov] of ventasOverrides.entries()) {
      const prev = merged.get(id) || merged.get(String(id)) || {};
      merged.set(id, { ...prev, ...ov });
    }
    return merged;
  }, [ventasMap, ventasOverrides]);

  const bizCtx = useBusiness();
  useEffect(() => {
  }, [bizCtx?.activeBusinessId, activeBizId]);

  const handleRedondeoChange = useCallback(async (nuevoValor) => {
    saveRedondeoConfig(Number(activeBizId), nuevoValor, true);
    try {
      await BusinessesAPI.update(Number(activeBizId), { props: { redondeo_precios: nuevoValor } });
    } catch (e) {
      console.warn('[handleRedondeoChange] error:', e.message);
    }
  }, [activeBizId]);

  // ── Estado vacío: sin negocio activo ──
  const [showCreateBiz, setShowCreateBiz] = React.useState(false);
  if (!activeBizId) {
    return (
      <Box sx={{
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        minHeight: '60vh', gap: 3, p: 4,
      }}>
        <Box sx={{ fontSize: 64, lineHeight: 1 }}>🏪</Box>
        <Box sx={{ textAlign: 'center' }}>
          <Typography variant="h5" fontWeight={800} gutterBottom>
            ¡Bienvenido a Lazarillo!
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ maxWidth: 420 }}>
            Todavía no tenés ningún negocio configurado. Creá tu primer negocio para empezar a gestionar artículos, precios y ventas.
          </Typography>
        </Box>
        <Button
          variant="contained" size="large"
          startIcon={<span style={{ fontSize: '1.2rem' }}>+</span>}
          onClick={() => setShowCreateBiz(true)}
          sx={{
            px: 4, py: 1.5, borderRadius: 2, fontWeight: 700, fontSize: '1rem',
            bgcolor: 'var(--color-primary, #3b82f6)',
            '&:hover': { filter: 'brightness(0.9)', bgcolor: 'var(--color-primary, #3b82f6)' },
          }}>
          Crear mi primer negocio
        </Button>
        <BusinessCreateModal
          open={showCreateBiz}
          onClose={() => setShowCreateBiz(false)}
          onCreateComplete={async (biz) => {
            setShowCreateBiz(false);
            if (biz?.id) {
              try { window.dispatchEvent(new CustomEvent('business:created', { detail: { id: biz.id } })); } catch { }
            }
          }}
        />
      </Box>
    );
  }

  // Vista de organización: early return cuando el principal está vacío y hay subnegocios
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: '12px 8px 0 8px' }}>
        <h2 style={{ margin: 0 }}>
          Gestión de Artículos
          {activeBranch && (
            <span style={{
              marginLeft: 10, fontSize: '0.6em', fontWeight: 500,
              color: activeBranch.color || 'var(--color-primary)',
              verticalAlign: 'middle',
            }}>
              — {activeBranch.name}
            </span>
          )}
        </h2>

        {isSyncing && (
          <Alert
            severity="info"
            icon={false}
            sx={{
              mb: 1,
              display: 'flex',
              alignItems: 'center',
              gap: 1,
              background: 'var(--color-primary, #1976d2)15',
              borderLeft: '3px solid var(--color-primary, #1976d2)',
            }}
          >
            <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              {/* Spinner simple sin importar CircularProgress extra */}
              <span style={{
                width: 14, height: 14, borderRadius: '50%',
                border: '2px solid var(--color-primary, #1976d2)',
                borderTopColor: 'transparent',
                animation: 'spin 0.8s linear infinite',
                display: 'inline-block',
              }} />
              <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
              <strong>Sincronización en curso</strong>
              {syncMsg && <span style={{ color: '#555', fontSize: '0.85em' }}>— {syncMsg}</span>}
            </span>
          </Alert>
        )}

        {ventasError && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            Error al cargar ventas: {ventasError}
          </Alert>
        )}

        <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
          <SalesPickerIcon
            value={rango}
            onChange={handleRangoChange}
            firstDate={firstDateVentas}
            loadingFirst={loadingFirstVentas}
            labelOverride={activeBranchFilter?.mode === 'all' ? '' : null}
          />
          <VentasActionsMenu
            rango={rango}
            onImport={() => setUploadModalOpen(true)}
            onExport={handleDownloadVentasCsv}
            disabled={!activeBizId || ventasLoading}
            allBusinesses={allBusinesses}
            activeBizId={activeBizId}
            branches={rawBranches || []}
            lists={lists}
            activeListId={activeListId}
            activeListItems={activeListItems}
            alertaVentas={alertaVentas}
          />
          <SucursalSelector variant="inline" />
          <SelectionToolbar
            selectionMode={selectionMode}
            selectedIds={selectedIds}
            saving={selectionSaving}
            existingLists={lists}
            onToggleMode={toggleMode}
            onClearSelection={clearSelection}
            onCreateList={createList}
            onAddToList={addToExistingList}
            onCreateLink={createLink}
            onDeleteList={deleteList}
            onDownloadList={handleDownloadList}
          />
          <div style={{ minWidth: 260, maxWidth: 360 }}>
            <Buscador
              placeholder="Buscar artículos..."
              opciones={opcionesBuscador}
              value={searchText}
              onChange={(v) => setSearchText(v || '')}
              clearOnPick={false}
              autoFocusAfterPick
              noResultsText="No se encontró ningún artículo"
              onPick={(opt) => {
                const id = Number(opt?.id);
                if (!Number.isFinite(id)) return;
                setFiltroBusqueda('');
                setSearchText('');
                focusArticle(id);
              }}
            />
          </div>
        </div>
      </div>

      <div style={{
        display: 'grid', gridTemplateColumns: '280px 1fr', gap: 0, alignItems: 'start',
        borderRadius: 12, overflow: 'hidden', height: '75vh',
        boxShadow: '0 1px 4px rgba(0,0,0,.08)'
      }}>
        <div
          ref={sidebarScrollRef}
          style={{
            borderRight: '1px solid #eee', background: '#fafafa',
            position: 'sticky', top: 0, alignSelf: 'start',
            height: 'calc(100vh - 0px)', overflowY: 'auto'
          }}>
          <SidebarCategorias
            categorias={categorias}
            categoriaSeleccionada={categoriaSeleccionada}
            setCategoriaSeleccionada={setCategoriaSeleccionada}
            agrupaciones={agrupacionesOrdenadas}
            agrupacionSeleccionada={agrupacionSeleccionada}
            setAgrupacionSeleccionada={setAgrupacionSeleccionada}
            setFiltroBusqueda={setFiltroBusqueda}
            setBusqueda={setFiltroBusqueda}
            todoGroupId={todoInfo.todoGroupId}
            todoCountOverride={
              todoInfo.todoGroupId ? { [todoInfo.todoGroupId]: todoInfo.idsSinAgrupCount } : {}
            }
            listMode={sidebarListMode}
            visibleIds={effectiveVisibleIds}
            lists={lists}
            activeListId={activeListId}
            onSelectList={selectList}
            onDeleteList={deleteList}
            onDownloadList={handleDownloadList}
            onManualPick={markManualPick}
            onChangeListMode={handleChangeListMode}
            priceConfig={priceConfig}
            globalCostoIdeal={globalCostoIdeal}
            onPriceConfigSave={handlePriceConfigSave}
            agrupacionArticuloIds={agrupacionArticuloIds}
            favoriteGroupId={favoriteGroupId}
            onSetFavorite={handleSetFavorite}
            onEditGroup={handleRenameGroup}
            onDeleteGroup={handleDeleteGroup}
            onRenameGroup={handleRenameGroup}
            ventasMap={ventasMap}
            metaById={metaById}
            getAmountForId={getAmountForId}
            onMutateGroups={mutateGroups}
            onRefetch={refetchAgrupaciones}
            notify={showMiss}
            onCreateSubBusiness={(agrupacion) => {
              setGroupForSubBiz(agrupacion);
              setSubBizModalOpen(true);
            }}
            activeDivisionId={activeDivisionId}
            firstDate={firstDateVentas}
            loadingFirst={loadingFirstVentas}
            activeDivisionAgrupacionIds={activeDivisionAgrupacionIds}
            assignedAgrupacionIds={assignedAgrupacionIds}
            refetchAssignedAgrupaciones={refetchAssignedAgrupaciones}
            totalBizAmount={totalBizAmount}
            businessId={activeBizId}
            visibleSubrubro={visibleSubrubro}
          />
        </div>

        <div
          id="tabla-scroll"
          style={{ background: '#fff', overflow: 'visible', maxHeight: 'calc(100vh - 0px)' }}>
          <TablaArticulos
            branches={[]}
            ventasMapByBranch={{}}
            filtroBusqueda={''}
            agrupaciones={agrupacionesOrdenadas}
            orgAssignedIds={orgAssignedIds}
            agrupacionSeleccionada={agrupacionSeleccionada}
            setAgrupacionSeleccionada={setAgrupacionSeleccionada}
            categoriaSeleccionada={categoriaSeleccionada}
            setCategoriaSeleccionada={setCategoriaSeleccionada}
            refetchAgrupaciones={refetchAgrupaciones}
            fechaDesdeProp={periodo.from}
            fechaHastaProp={periodo.to}
            ventasPorArticulo={ventasPorArticuloMerged}
            ventasLoading={ventasLoading}
            onCategoriasLoaded={handleCategoriasLoaded}
            onIdsVisibleChange={setActiveIds}
            activeBizId={activeBizId}
            rootBizId={rootBusiness?.id ? Number(rootBusiness.id) : null}
            reloadKey={reloadKey}
            syncVersion={syncVersion}
            onTodoInfo={handleTodoInfo}
            onTotalResolved={handleTotalResolved}
            onGroupCreated={handleGroupCreated}
            onMutateGroups={mutateGroups}
            visibleIds={effectiveVisibleIds}
            favoriteGroupId={favoriteGroupId}
            onSetFavorite={handleSetFavorite}
            jumpToArticleId={jumpToId}
            selectedArticleId={selectedArticleId}
            onActualizar={() => setReloadKey(k => k + 1)}
            tableHeaderMode={tableHeaderMode}
            onDiscontinuadoChange={handleDiscontinuadoChange}
            modalTreeMode={modalTreeMode}
            onDiscontinuarBloque={handleDiscontinuarBloque}
            getAmountForId={getAmountForId}
            discIds={effectiveDiscIds}
            recetasCostos={recetasCostos}
            priceConfig={priceConfig}
            globalCostoIdeal={globalCostoIdeal}
            onPriceConfigSave={handlePriceConfigSave}
            onBulkManualSave={handleBulkManualSave}
            onSaved={handleRecetaSaved}
            selectionMode={selectionMode}
            selectedIds={selectedIds}
            onToggleSelected={toggleSelected}
            onSelectAll={selectAll}
            linkByArticleId={linkByArticleId}
            nameById={nameById}
            onRemoveMemberFromLink={removeMemberFromLink}
            onDeleteLink={deleteLink}
            onRedondeoChange={handleRedondeoChange}
            allPriceLists={allPriceLists}
            onVisibleSubrubroChange={setVisibleSubrubro}
          />
        </div>
      </div>
      <Snackbar
        open={missOpen}
        autoHideDuration={3500}
        onClose={() => setMissOpen(false)}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert onClose={() => setMissOpen(false)} severity="info" sx={{ width: '100%' }}>
          {missMsg}
        </Alert>
      </Snackbar>

      {/* ── Diálogo de confirmación — ¿pisar overrides manuales? ── */}
      <Dialog open={!!dlgConfirm} onClose={() => setDlgConfirm(null)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>
          Cambio de objetivo %
        </DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ mb: 1 }}>
            {dlgConfirm?.conOverride === dlgConfirm?.total
              ? `Los ${dlgConfirm?.total} artículos ya tienen objetivo % individual.`
              : `${dlgConfirm?.conOverride} de ${dlgConfirm?.total} artículos ya tienen objetivo % individual.`
            }
          </Typography>
          <Typography variant="body2" color="text.secondary">
            ¿A cuáles aplicar el nuevo objetivo?
          </Typography>
        </DialogContent>
        <DialogActions sx={{ flexDirection: 'column', alignItems: 'stretch', gap: 1, px: 2, pb: 2 }}>
          <Button
            onClick={() => { dlgConfirm?.doSave(false); setDlgConfirm(null); }}
            variant="contained"
            size="small"
            sx={{ textTransform: 'none', justifyContent: 'flex-start' }}
          >
            Solo los que NO tienen objetivo individual ({(dlgConfirm?.total ?? 0) - (dlgConfirm?.conOverride ?? 0)} artículos)
          </Button>
          <Button
            onClick={() => { dlgConfirm?.doSave(true); setDlgConfirm(null); }}
            variant="outlined"
            size="small"
            sx={{ textTransform: 'none', justifyContent: 'flex-start' }}
          >
            Aplicar a todos (incluye los {dlgConfirm?.conOverride} con objetivo individual)
          </Button>
          <Button
            onClick={() => setDlgConfirm(null)}
            variant="text" size="small" color="inherit"
            sx={{ textTransform: 'none' }}
          >
            Cancelar
          </Button>
        </DialogActions>
      </Dialog>

      {/* El deshacer de objetivo_update se maneja desde el panel de notificaciones */}
      <UploadCSVModal
        open={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        businessId={activeBizId}
        onSuccess={() => {
          clearVentasCache();
          setSyncVersion(v => v + 1);
          showMiss('✅ Ventas importadas correctamente');
        }}
        instructionImage1={instructionImage1}
        instructionImage2={instructionImage2}
        activeBranchId={activeBranch?.id}
      />

      {/* Modal de creación de sub-negocio — aquí para evitar re-renders de SidebarCategorias */}
      <SubBusinessCreateModal
        open={subBizModalOpen}
        agrupacion={groupForSubBiz}
        onClose={handleSubBizClose}
        onCreated={handleSubBizCreated}
        onNeedOrgName={handleNeedOrgName}
      />

      {/* Modal para nombrar la organización — portal para escapar cualquier overflow/stacking */}
      {orgNameModalOpen && ReactDOM.createPortal(
        <div style={{
          position: 'fixed', inset: 0,
          background: 'rgba(10,12,16,.72)',
          backdropFilter: 'blur(6px)',
          display: 'grid', placeItems: 'center',
          zIndex: 100001,
        }}>
          <div style={{
            width: 'min(460px, 94vw)',
            background: '#fff',
            borderRadius: 18,
            padding: '32px 28px 24px',
            boxShadow: '0 8px 40px rgba(0,0,0,.22)',
            display: 'flex', flexDirection: 'column', gap: 16,
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 40, marginBottom: 8 }}>🏢</div>
              <h3 style={{ margin: 0, fontSize: '1.1rem', fontWeight: 800 }}>
                ¿Cómo se llama tu organización?
              </h3>
              <p style={{ margin: '8px 0 0', fontSize: '.88rem', color: '#666', lineHeight: 1.5 }}>
                Tu organización agrupa a todos tus negocios. Podés cambiar este nombre cuando quieras desde Perfil.
              </p>
            </div>
            <input
              type="text"
              value={orgNameInput}
              onChange={e => setOrgNameInput(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && orgNameInput.trim() && !orgNameSaving) {
                  (async () => {
                    setOrgNameSaving(true);
                    try { await updateOrg(orgNameInput.trim()); } catch { }
                    setOrgNameSaving(false);
                    setOrgNameModalOpen(false);
                  })();
                }
              }}
              placeholder={`Ej: ${organization?.name || 'Mi Grupo'}`}
              autoFocus
              style={{
                width: '100%', boxSizing: 'border-box',
                padding: '11px 14px', fontSize: '.95rem', fontWeight: 600,
                border: '2px solid #e0e0e5', borderRadius: 10, outline: 'none',
              }}
            />
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 4 }}>
              <button
                onClick={() => setOrgNameModalOpen(false)}
                disabled={orgNameSaving}
                style={{ border: 'none', background: 'none', color: '#999', fontSize: '.85rem', cursor: 'pointer', padding: '8px 12px' }}>
                Omitir por ahora
              </button>
              <button
                disabled={orgNameSaving || !orgNameInput.trim()}
                onClick={async () => {
                  setOrgNameSaving(true);
                  try { await updateOrg(orgNameInput.trim()); } catch { }
                  setOrgNameSaving(false);
                  setOrgNameModalOpen(false);
                }}
                style={{
                  border: 'none', borderRadius: 10, padding: '11px 24px',
                  fontSize: '.88rem', fontWeight: 800, cursor: 'pointer',
                  background: '#1a1a2e', color: '#fff',
                  opacity: (orgNameSaving || !orgNameInput.trim()) ? .5 : 1,
                }}>
                {orgNameSaving ? 'Guardando…' : 'Guardar nombre'}
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}