// src/componentes/configuracion/ABMModals.jsx
// Modales de alta manual de artículos e insumos
import React, { useState, useEffect, useMemo } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, TextField, Stack, Alert, Box, Typography,
  FormControl, InputLabel, Select, MenuItem,
  InputAdornment, Divider, CircularProgress,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import { BASE } from '@/servicios/apiBase';

const UNIDADES_INSUMO = ['gr', 'kg', 'ml', 'lt', 'u', 'oz', 'cc', 'taza', 'cdita', 'cda', 'doc'];

/* ─── Alta de Insumo ─── */
export function InsumoNuevoModal({ open, onClose, businessId, onCreated }) {
  const themeColor = 'var(--color-primary, #3b82f6)';
  const [form, setForm] = useState({
    nombre: '', rubro: '', rubroNuevo: '', unidadMed: 'u', precioRef: '', esElaborado: false,
  });
  const [rubros, setRubros]   = useState([]);
  const [saving, setSaving]   = useState(false);
  const [error, setError]     = useState('');
  const [success, setSuccess] = useState(null);

  useEffect(() => {
    if (!open || !businessId) return;
    const token = localStorage.getItem('token') || '';
    fetch(`${BASE}/insumos/rubros`, {
      headers: { Authorization: `Bearer ${token}`, 'X-Business-Id': String(businessId) },
    }).then(r => r.json()).catch(() => ({}))
      .then(d => setRubros((d?.rubros || []).map(r => r.nombre)));
  }, [open, businessId]);

  const rubroFinal = form.rubro === '__nuevo__' ? form.rubroNuevo.trim() : form.rubro;

  const handleSave = async () => {
    if (!form.nombre.trim()) { setError('El nombre es obligatorio'); return; }
    if (!rubroFinal) { setError('El rubro es obligatorio'); return; }
    setSaving(true); setError('');
    try {
      const token = localStorage.getItem('token') || '';
      const res = await fetch(`${BASE}/insumos`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'X-Business-Id': String(businessId),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nombre: form.nombre.trim(), rubro: rubroFinal,
          unidadMed: form.unidadMed || 'u',
          precioRef: form.precioRef ? Number(form.precioRef) : null,
          es_elaborado: form.esElaborado, origen: 'manual',
        }),
      });
      const data = await res.json();
      if (res.status === 409) { setError(data.error + (data.existing ? ` (ID: ${data.existing.id})` : '')); setSaving(false); return; }
      if (!res.ok) throw new Error(data?.error || `Error ${res.status}`);
      setSuccess(data.data);
      onCreated?.(data.data);
      setTimeout(() => {
        setSuccess(null);
        setForm({ nombre: '', rubro: '', rubroNuevo: '', unidadMed: 'u', precioRef: '', esElaborado: false });
        onClose();
      }, 1500);
    } catch (e) {
      setError(e.message || 'Error al crear el insumo');
    } finally { setSaving(false); }
  };

  const handleClose = () => {
    if (saving) return;
    setForm({ nombre: '', rubro: '', rubroNuevo: '', unidadMed: 'u', precioRef: '', esElaborado: false });
    setError(''); setSuccess(null); onClose();
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem', pb: 1 }}>Nuevo insumo</DialogTitle>
      <DialogContent>
        <Stack spacing={2} pt={0.5}>
          {error   && <Alert severity="error"   sx={{ py: 0.5, fontSize: '0.82rem' }}>{error}</Alert>}
          {success && (
            <Alert severity="success" sx={{ py: 0.5, fontSize: '0.82rem' }}>
              Insumo <strong>{success.nombre}</strong> creado — SKU: <code>{success.codigo_maxi}</code>
            </Alert>
          )}

          <TextField label="Nombre *" size="small" fullWidth autoFocus
            value={form.nombre} onChange={e => setForm(f => ({ ...f, nombre: e.target.value }))}
            disabled={saving || !!success} />

          <Stack direction="row" spacing={1.5}>
            <FormControl size="small" sx={{ flex: 1 }}>
              <InputLabel>Rubro *</InputLabel>
              <Select label="Rubro *" value={form.rubro} disabled={saving || !!success}
                onChange={e => setForm(f => ({ ...f, rubro: e.target.value, rubroNuevo: '' }))}>
                {rubros.map(r => <MenuItem key={r} value={r}>{r}</MenuItem>)}
                <Divider />
                <MenuItem value="__nuevo__" sx={{ color: themeColor, fontStyle: 'italic' }}>+ Rubro nuevo…</MenuItem>
              </Select>
            </FormControl>
            {form.rubro === '__nuevo__' && (
              <TextField label="Nombre del rubro" size="small" sx={{ flex: 1 }} autoFocus
                value={form.rubroNuevo} disabled={saving || !!success}
                onChange={e => setForm(f => ({ ...f, rubroNuevo: e.target.value }))} />
            )}
          </Stack>

          <Stack direction="row" spacing={1.5}>
            <FormControl size="small" sx={{ width: 140 }}>
              <InputLabel>Unidad</InputLabel>
              <Select label="Unidad" value={form.unidadMed} disabled={saving || !!success}
                onChange={e => setForm(f => ({ ...f, unidadMed: e.target.value }))}>
                {UNIDADES_INSUMO.map(u => <MenuItem key={u} value={u}>{u}</MenuItem>)}
              </Select>
            </FormControl>
            <TextField label="Precio de referencia" size="small" type="number" sx={{ flex: 1 }}
              value={form.precioRef} disabled={saving || !!success}
              onChange={e => setForm(f => ({ ...f, precioRef: e.target.value }))}
              InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment> }} />
          </Stack>

          <Box sx={{
            display: 'flex', alignItems: 'center', gap: 1.5,
            p: 1.5, borderRadius: 1.5, border: '1px solid #e2e8f0',
            bgcolor: form.esElaborado ? `${themeColor}08` : 'transparent',
            cursor: 'pointer', transition: 'all .15s',
            '&:hover': { borderColor: themeColor },
          }} onClick={() => !saving && !success && setForm(f => ({ ...f, esElaborado: !f.esElaborado }))}>
            <Box sx={{
              width: 18, height: 18, borderRadius: '50%', flexShrink: 0,
              border: `2px solid ${form.esElaborado ? themeColor : '#cbd5e1'}`,
              bgcolor: form.esElaborado ? themeColor : 'transparent',
              display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all .15s',
            }}>
              {form.esElaborado && <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#fff' }} />}
            </Box>
            <Box>
              <Typography variant="body2" fontWeight={form.esElaborado ? 700 : 500} sx={{ fontSize: '0.85rem' }}>
                {form.esElaborado ? 'Elaborado' : 'Insumo de compra'}
              </Typography>
              <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.75rem' }}>
                {form.esElaborado ? 'Se produce internamente — tiene su propia receta' : 'Se compra a un proveedor externo'}
              </Typography>
            </Box>
          </Box>

          <Alert severity="info" sx={{ py: 0.5, fontSize: '0.78rem' }}>
            Se generará un SKU provisorio automáticamente (<code>LAZ-...</code>).
            Cuando Maxi sincronice un insumo con el mismo nombre y rubro, lo reemplazará.
          </Alert>
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 2.5, pb: 2, gap: 1 }}>
        <Button size="small" color="inherit" onClick={handleClose} disabled={saving}>Cancelar</Button>
        <Button size="small" variant="contained" onClick={handleSave} disabled={saving || !!success}
          startIcon={saving ? <CircularProgress size={14} color="inherit" /> : <AddIcon />}
          sx={{ bgcolor: themeColor, '&:hover': { filter: 'brightness(0.9)', bgcolor: themeColor } }}>
          {saving ? 'Creando…' : 'Crear insumo'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

/* ─── Alta de Artículo ─── */
export function ArticuloNuevoModal({ open, onClose, businessId, onCreated }) {
  const themeColor = 'var(--color-primary, #3b82f6)';
  const EMPTY_FORM = { nombre: '', rubro: '', subrubro: '', precio: '', agrupacionId: '' };
  const [form, setForm]             = useState(EMPTY_FORM);
  const [rubroNuevo, setRubroNuevo] = useState('');
  const [subrubroNuevo, setSubrubroNuevo] = useState('');
  const [rubros, setRubros]         = useState([]);
  const [agrupaciones, setAgrupaciones] = useState([]);
  const [saving, setSaving]         = useState(false);
  const [error, setError]           = useState('');

  const subrubrosDelRubro = useMemo(() => {
    const r = rubros.find(r => r.nombre === form.rubro);
    return r?.subrubros || [];
  }, [rubros, form.rubro]);

  const esRubroNuevo    = form.rubro    === '__nuevo__';
  const esSubrubroNuevo = form.subrubro === '__nuevo__';

  useEffect(() => {
    if (!open || !businessId) return;
    const token   = localStorage.getItem('token') || '';
    const headers = { Authorization: `Bearer ${token}`, 'X-Business-Id': String(businessId) };
    Promise.all([
      fetch(`${BASE}/businesses/${businessId}/rubros`, { headers }).then(r => r.json()).catch(() => ({})),
      fetch(`${BASE}/businesses/${businessId}/agrupaciones`, { headers }).then(r => r.json()).catch(() => ({})),
    ]).then(([rubrosData, agData]) => {
      setRubros(rubrosData?.categorias || []);
      setAgrupaciones(Array.isArray(agData) ? agData : (agData?.agrupaciones || []));
    });
  }, [open, businessId]);

  useEffect(() => {
    if (!open) {
      setForm(EMPTY_FORM); setRubroNuevo(''); setSubrubroNuevo(''); setError('');
    }
  }, [open]);

  const rubroEfectivo    = esRubroNuevo    ? rubroNuevo.trim()    : form.rubro;
  const subrubroEfectivo = esSubrubroNuevo ? subrubroNuevo.trim() : form.subrubro;

  const handleSave = async () => {
    if (!form.nombre.trim()) { setError('El nombre es obligatorio'); return; }
    if (!rubroEfectivo)      { setError('El rubro es obligatorio');  return; }
    setSaving(true); setError('');
    try {
      const token = localStorage.getItem('token') || '';
      const res = await fetch(`${BASE}/businesses/${businessId}/articles/manual`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'X-Business-Id': String(businessId),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nombre:       form.nombre.trim(),
          rubro:        rubroEfectivo,
          subrubro:     subrubroEfectivo || null,
          precio:       form.precio ? Number(form.precio) : 0,
          agrupacionId: form.agrupacionId ? Number(form.agrupacionId) : null,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || `Error ${res.status}`);
      onCreated?.(data.articulo);
      onClose();
    } catch (e) {
      setError(e.message || 'Error al crear el artículo');
    } finally { setSaving(false); }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem', pb: 1 }}>Nuevo artículo</DialogTitle>
      <DialogContent>
        <Stack spacing={2} pt={0.5}>
          {error && <Alert severity="error" sx={{ py: 0.5, fontSize: '0.82rem' }}>{error}</Alert>}

          <TextField label="Nombre *" size="small" fullWidth autoFocus
            value={form.nombre} onChange={e => setForm(f => ({ ...f, nombre: e.target.value }))} />

          {/* ── Rubro ── */}
          <Stack direction="row" spacing={1.5}>
            <Stack sx={{ flex: 1 }} spacing={0.75}>
              <FormControl size="small" fullWidth>
                <InputLabel>Rubro *</InputLabel>
                <Select label="Rubro *" value={form.rubro}
                  onChange={e => setForm(f => ({
                    ...f, rubro: e.target.value, subrubro: '',
                  }))}>
                  {rubros.length === 0 && (
                    <MenuItem disabled value="">
                      <em style={{ color: '#94a3b8', fontSize: '0.82rem' }}>Sin rubros aún</em>
                    </MenuItem>
                  )}
                  {rubros.map(r => <MenuItem key={r.nombre} value={r.nombre}>{r.nombre}</MenuItem>)}
                  <Divider />
                  <MenuItem value="__nuevo__" sx={{ color: themeColor, fontStyle: 'italic' }}>
                    + Crear rubro nuevo…
                  </MenuItem>
                </Select>
              </FormControl>
              {esRubroNuevo && (
                <TextField size="small" fullWidth autoFocus
                  label="Nombre del rubro nuevo"
                  placeholder="Ej: Bebidas, Comidas, Postres…"
                  value={rubroNuevo}
                  onChange={e => setRubroNuevo(e.target.value)}
                />
              )}
            </Stack>

            {/* ── Subrubro ── */}
            <Stack sx={{ flex: 1 }} spacing={0.75}>
              <FormControl size="small" fullWidth>
                <InputLabel>Subrubro</InputLabel>
                <Select label="Subrubro" value={form.subrubro}
                  onChange={e => setForm(f => ({ ...f, subrubro: e.target.value }))}
                  disabled={!rubroEfectivo}>
                  <MenuItem value="">Sin subrubro</MenuItem>
                  {subrubrosDelRubro.map(s => <MenuItem key={s} value={s}>{s}</MenuItem>)}
                  {(subrubrosDelRubro.length > 0 || esRubroNuevo) && <Divider />}
                  <MenuItem value="__nuevo__" sx={{ color: themeColor, fontStyle: 'italic' }}>
                    + Crear subrubro nuevo…
                  </MenuItem>
                </Select>
              </FormControl>
              {esSubrubroNuevo && (
                <TextField size="small" fullWidth autoFocus
                  label="Nombre del subrubro nuevo"
                  placeholder="Ej: Cócteles, Sin alcohol…"
                  value={subrubroNuevo}
                  onChange={e => setSubrubroNuevo(e.target.value)}
                />
              )}
            </Stack>
          </Stack>

          <Stack direction="row" spacing={1.5}>
            <TextField label="Precio inicial" size="small" type="number" fullWidth
              value={form.precio} onChange={e => setForm(f => ({ ...f, precio: e.target.value }))}
              InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment> }} />
            <FormControl size="small" fullWidth>
              <InputLabel>Agrupación</InputLabel>
              <Select label="Agrupación" value={form.agrupacionId}
                onChange={e => setForm(f => ({ ...f, agrupacionId: e.target.value }))}>
                <MenuItem value="">Sin agrupación</MenuItem>
                {agrupaciones
                  .filter(a => !a.nombre?.toLowerCase().includes('sin agrupac') && !a.nombre?.toLowerCase().includes('discontinu'))
                  .map(a => <MenuItem key={a.id} value={a.id}>{a.nombre}</MenuItem>)
                }
              </Select>
            </FormControl>
          </Stack>

          <Alert severity="info" sx={{ py: 0.5, fontSize: '0.78rem' }}>
            Se generará un SKU provisorio automáticamente. Podés agregar el código externo (Maxi) después para vincularlo.
          </Alert>
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 2.5, pb: 2 }}>
        <Button size="small" color="inherit" onClick={onClose}>Cancelar</Button>
        <Button size="small" variant="contained" onClick={handleSave} disabled={saving}
          startIcon={saving ? <CircularProgress size={14} color="inherit" /> : <AddIcon />}
          sx={{ bgcolor: themeColor, '&:hover': { filter: 'brightness(0.9)', bgcolor: themeColor } }}>
          {saving ? 'Creando…' : 'Crear artículo'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}