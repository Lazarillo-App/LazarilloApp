// src/componentes/VentasActionsMenu.jsx
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  Button, Menu, MenuItem, ListItemIcon, ListItemText,
  Divider, Typography, Box, Chip,
  Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, CircularProgress, FormControlLabel, Radio, RadioGroup,
  Tooltip,
} from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import CloudDownloadIcon from '@mui/icons-material/CloudDownload';
import SyncIcon from '@mui/icons-material/Sync';
import FilterListIcon from '@mui/icons-material/FilterList';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

// ── Leer colores del tema ────────────────────────────────────────────────────
function readColors() {
  if (typeof window === 'undefined') return { primary: '#3b82f6', secondary: '#10b981', onPrimary: '#ffffff' };
  const s = getComputedStyle(document.documentElement);
  return {
    primary: s.getPropertyValue('--color-primary')?.trim() || '#3b82f6',
    secondary: s.getPropertyValue('--color-secondary')?.trim() || '#10b981',
    onPrimary: s.getPropertyValue('--on-primary')?.trim() || '#ffffff',
  };
}

// ── Modal de exportación ─────────────────────────────────────────────────────
function ExportModal({
  open,
  onClose,
  onConfirm,       // ({ businessIdOverride, branchId, articleIds }) => Promise<void>
  rango,
  allBusinesses = [],      // [{id, nombre, name}] — todos los negocios de la org
  activeBizId,             // negocio activo actual
  branches = [],           // sucursales del negocio seleccionado
  lists = [],              // listas guardadas [{id, name, item_count}]
  activeListId = null,     // lista activa en el sidebar (pre-seleccionar)
  activeListItems = null,  // Set<number> con los IDs de la lista activa
  isExporting = false,
}) {
  // ── Negocio seleccionado
  const [selectedBizId, setSelectedBizId] = useState('');
  // ── Sucursal: 'all' | 'main' | número como string
  const [selectedBranch, setSelectedBranch] = useState('all');
  // ── Filtro de artículos: 'all' | 'list'
  const [articleFilter, setArticleFilter] = useState('all');
  // ── Lista seleccionada
  const [selectedListId, setSelectedListId] = useState('');

  const negocios = useMemo(() => (allBusinesses || []).filter(b => Number(b.id) > 0), [allBusinesses]);
  const showBizSelect = negocios.length > 1;

  // Pre-seleccionar al abrir
  useEffect(() => {
    if (!open) return;
    setSelectedBizId(String(activeBizId || ''));
    setSelectedBranch('all');
    // Pre-seleccionar lista si hay una activa en el sidebar
    if (activeListId) {
      setArticleFilter('list');
      setSelectedListId(String(activeListId));
    } else {
      setArticleFilter('all');
      setSelectedListId('');
    }
  }, [open, activeBizId, activeListId]);

  const rangoLabel = useMemo(() => {
    if (!rango?.from || !rango?.to) return 'Sin período';
    try {
      const fromStr = format(new Date(rango.from), 'dd/MM/yy', { locale: es });
      const toStr = format(new Date(rango.to), 'dd/MM/yy', { locale: es });
      return `${fromStr} — ${toStr}`;
    } catch { return 'Período seleccionado'; }
  }, [rango]);

  // Sucursales disponibles para el negocio seleccionado
  // (por ahora usamos las que vienen como prop — del negocio activo)
  // Si en el futuro querés cargar sucursales de otro negocio, agregá un useEffect aquí
  const branchesDisponibles = useMemo(() => {
    if (Number(selectedBizId) !== Number(activeBizId)) return [];
    return branches || [];
  }, [selectedBizId, activeBizId, branches]);

  const handleConfirm = useCallback(() => {
    const bizOverride = Number(selectedBizId) !== Number(activeBizId)
      ? Number(selectedBizId)
      : null;

    // branch_id
    let branchId = null;
    if (selectedBranch === 'main') branchId = 'main';
    else if (selectedBranch !== 'all') branchId = Number(selectedBranch);

    // article_ids
    let articleIds = null;
    if (articleFilter === 'list' && selectedListId) {
      // Si la lista seleccionada es la activa y tenemos sus IDs en memoria → usarlos directo
      if (Number(selectedListId) === Number(activeListId) && activeListItems instanceof Set) {
        articleIds = activeListItems;
      }
      // Si no tenemos los IDs en memoria, pasamos el listId y dejamos que
      // el llamador los resuelva (ver ArticulosMain.handleDownloadVentasCsv)
      else {
        articleIds = { listId: Number(selectedListId) };
      }
    }

    onConfirm({ businessIdOverride: bizOverride, branchId, articleIds, listId: Number(selectedListId) || null });
  }, [selectedBizId, activeBizId, selectedBranch, articleFilter, selectedListId, activeListId, activeListItems, onConfirm]);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem', pb: 1 }}>
        Exportar ventas
      </DialogTitle>

      <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '8px !important' }}>

        {/* Período */}
        <Box sx={{ p: 1.5, borderRadius: 1.5, bgcolor: 'action.hover', display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography variant="caption" color="text.secondary" sx={{ flexShrink: 0 }}>📅 Período:</Typography>
          <Chip label={rangoLabel} size="small" sx={{ fontWeight: 600, fontSize: '0.75rem' }} />
        </Box>

        {/* Negocio (solo si hay más de uno) */}
        {showBizSelect && (
          <TextField
            select SelectProps={{ native: true }}
            label="Negocio"
            value={selectedBizId}
            onChange={e => { setSelectedBizId(e.target.value); setSelectedBranch('all'); }}
            fullWidth size="small"
          >
            {negocios.map(b => (
              <option key={b.id} value={b.id}>
                {b.nombre || b.name || `Negocio #${b.id}`}
                {Number(b.id) === Number(activeBizId) ? ' (actual)' : ''}
              </option>
            ))}
          </TextField>
        )}

        {/* Sucursal */}
        <div>
          <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
            Sucursal
          </Typography>
          <RadioGroup
            value={selectedBranch}
            onChange={e => setSelectedBranch(e.target.value)}
          >
            <FormControlLabel value="all" control={<Radio size="small" />}
              label={<Typography variant="body2">Todas las sucursales</Typography>} />
            <FormControlLabel value="main" control={<Radio size="small" />}
              label={<Typography variant="body2">Solo negocio principal</Typography>} />
            {branchesDisponibles.map(branch => (
              <FormControlLabel
                key={branch.id}
                value={String(branch.id)}
                control={<Radio size="small" />}
                label={
                  <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <span style={{ width: 8, height: 8, borderRadius: '50%', background: branch.color || '#64748b', display: 'inline-block' }} />
                    {branch.name}
                  </Typography>
                }
              />
            ))}
          </RadioGroup>
          {Number(selectedBizId) !== Number(activeBizId) && (
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
              ⚠️ Las sucursales solo se muestran para el negocio actual.
            </Typography>
          )}
        </div>

        <Divider />

        {/* Filtro de artículos */}
        <div>
          <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
            Artículos a incluir
          </Typography>
          <RadioGroup
            value={articleFilter}
            onChange={e => setArticleFilter(e.target.value)}
          >
            <FormControlLabel value="all" control={<Radio size="small" />}
              label={<Typography variant="body2">Todos los artículos</Typography>} />
            {lists.length > 0 && (
              <FormControlLabel value="list" control={<Radio size="small" />}
                label={<Typography variant="body2">Solo los de una lista</Typography>} />
            )}
          </RadioGroup>

          {/* Select de lista */}
          {articleFilter === 'list' && lists.length > 0 && (
            <TextField
              select SelectProps={{ native: true }}
              value={selectedListId}
              onChange={e => setSelectedListId(e.target.value)}
              fullWidth size="small"
              sx={{ mt: 1 }}
              helperText={
                selectedListId
                  ? `${lists.find(l => String(l.id) === String(selectedListId))?.item_count ?? '?'} artículos`
                  : ''
              }
            >
              <option value="" disabled>Seleccionar lista…</option>
              {lists.map(list => (
                <option key={list.id} value={list.id}>
                  {list.name} ({list.item_count ?? '?'} art.)
                </option>
              ))}
            </TextField>
          )}

          {articleFilter === 'list' && lists.length === 0 && (
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
              No hay listas guardadas. Creá una seleccionando artículos.
            </Typography>
          )}
        </div>
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 2, gap: 1 }}>
        <Button onClick={onClose} disabled={isExporting} size="small" color="inherit">
          Cancelar
        </Button>
        <Button
          onClick={handleConfirm}
          variant="contained"
          size="small"
          disabled={isExporting || (articleFilter === 'list' && !selectedListId)}
          startIcon={isExporting ? <CircularProgress size={14} /> : <CloudDownloadIcon />}
          sx={{ textTransform: 'none', minWidth: 120 }}
        >
          {isExporting ? 'Exportando…' : 'Descargar CSV'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// ── Componente principal ─────────────────────────────────────────────────────
export default function VentasActionsMenu({
  onImport,
  onExport,          // ahora recibe ({ businessIdOverride, branchId, articleIds, listId })
  rango,
  disabled = false,
  // ── Nuevos props para el modal de exportación
  allBusinesses = [],
  activeBizId = null,
  branches = [],
  lists = [],
  activeListId = null,
  activeListItems = null,
}) {
  const [anchorEl, setAnchorEl] = useState(null);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const open = Boolean(anchorEl);

  const [themeColors, setThemeColors] = useState(readColors);
  useEffect(() => {
    const update = () => setThemeColors(readColors());
    window.addEventListener('palette:changed', update);
    window.addEventListener('theme:updated', update);
    window.addEventListener('business:switched', update);
    return () => {
      window.removeEventListener('palette:changed', update);
      window.removeEventListener('theme:updated', update);
      window.removeEventListener('business:switched', update);
    };
  }, []);

  const handleClick = (e) => setAnchorEl(e.currentTarget);
  const handleClose = () => setAnchorEl(null);

  const handleImport = () => { handleClose(); onImport?.(); };

  // Abrir modal de exportación en lugar de exportar directo
  const handleExportClick = () => {
    handleClose();
    setExportModalOpen(true);
  };

  const handleExportConfirm = useCallback(async (params) => {
    setIsExporting(true);
    try {
      await onExport?.(params);
    } finally {
      setIsExporting(false);
      setExportModalOpen(false);
    }
  }, [onExport]);

  const rangoLabel = useMemo(() => {
    if (!rango?.from || !rango?.to) return 'Sin período';
    try {
      const fromStr = format(new Date(rango.from), 'dd/MM/yy', { locale: es });
      const toStr = format(new Date(rango.to), 'dd/MM/yy', { locale: es });
      return `${fromStr} - ${toStr}`;
    } catch { return 'Período seleccionado'; }
  }, [rango]);

  return (
    <>
      <Button
        variant="contained"
        startIcon={<SyncIcon />}
        onClick={handleClick}
        disabled={disabled}
        sx={{
          textTransform: 'none',
          bgcolor: themeColors.primary,
          color: themeColors.onPrimary,
          '&:hover': { bgcolor: themeColors.primary, filter: 'brightness(0.9)' },
          boxShadow: 2,
          padding: '7.5px 9px',
        }}
      >
        Gestionar ventas
      </Button>

      <Menu
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          elevation: 3,
          sx: { minWidth: 280, mt: 1, borderRadius: 2, border: `1px solid ${themeColors.primary}20` },
        }}
        transformOrigin={{ horizontal: 'left', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
      >
        <Box sx={{ px: 2, py: 1.5, bgcolor: `${themeColors.primary}08` }}>
          <Typography variant="caption" sx={{ color: 'text.secondary', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            📊 Administrar datos
          </Typography>
        </Box>

        <Divider sx={{ my: 0.5 }} />

        <MenuItem onClick={handleImport} sx={{ py: 1.5, px: 2 }}>
          <ListItemIcon><CloudUploadIcon fontSize="small" sx={{ color: themeColors.primary }} /></ListItemIcon>
          <ListItemText>
            <Typography variant="body2" sx={{ fontWeight: 500 }}>Importar ventas</Typography>
            <Typography variant="caption" color="text.secondary">Subir archivo CSV/Excel</Typography>
          </ListItemText>
        </MenuItem>

        <Divider sx={{ my: 0.5 }} />

        <MenuItem onClick={handleExportClick} sx={{ py: 1.5, px: 2 }}>
          <ListItemIcon><CloudDownloadIcon fontSize="small" sx={{ color: themeColors.secondary }} /></ListItemIcon>
          <ListItemText>
            <Typography variant="body2" sx={{ fontWeight: 500 }}>Exportar ventas</Typography>
            <Typography variant="caption" color="text.secondary">
              {activeListId
                ? '📋 Lista activa · negocio · sucursal'
                : 'Filtrar por negocio, sucursal o lista'}
            </Typography>
          </ListItemText>
          {activeListId && (
            <Chip label="Lista" size="small" sx={{ ml: 1, fontSize: '0.65rem', height: 18, bgcolor: `${themeColors.primary}15`, color: themeColors.primary }} />
          )}
        </MenuItem>

        <Box sx={{ px: 2, py: 1.5, bgcolor: `${themeColors.secondary}08`, borderTop: `1px solid ${themeColors.secondary}20`, mt: 0.5 }}>
          <Typography variant="caption" sx={{ color: 'text.secondary', display: 'block', mb: 0.5 }}>📅 Rango actual:</Typography>
          <Chip label={rangoLabel} size="small" sx={{ bgcolor: `${themeColors.secondary}15`, color: themeColors.secondary, fontWeight: 500, fontSize: '0.75rem' }} />
        </Box>
      </Menu>

      {/* Modal de exportación */}
      <ExportModal
        open={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
        onConfirm={handleExportConfirm}
        rango={rango}
        allBusinesses={allBusinesses}
        activeBizId={activeBizId}
        branches={branches}
        lists={lists}
        activeListId={activeListId}
        activeListItems={activeListItems}
        isExporting={isExporting}
      />
    </>
  );
}